﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlternateCapitalizeDemo
{
    static class AlternateNewstring
    {
        public static void AlternateCapitalize(this String ab,string ptr)
        {
            char[] arr = new char[ptr.Length];

            for (var i = 0; i < ptr.Length; i++)
            {
                if (i % 2 == 0)
                {
                    arr[i] = char.ToUpper(ptr[i]);
                }
                else
                {
                    arr[i] = char.ToLower(ptr[i]);
                }
            }

            Console.WriteLine(arr);
        }
    }
}
