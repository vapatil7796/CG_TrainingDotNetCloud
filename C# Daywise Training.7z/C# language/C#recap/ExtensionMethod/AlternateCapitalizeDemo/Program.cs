﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlternateCapitalizeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            String name = "Vishal";
            name.AlternateCapitalize(name);
        }
    }
}
