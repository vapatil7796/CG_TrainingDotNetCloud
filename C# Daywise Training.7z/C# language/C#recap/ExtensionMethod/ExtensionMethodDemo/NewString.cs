﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethodDemo
{
    static class NewString   //static required
    {
        public static void Print(this String sr,int no)    //static required and syntax: [this class_name varname]
        {
            Console.WriteLine("I am an Extension Method "+no);
        }
    }
}
