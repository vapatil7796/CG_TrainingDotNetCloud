﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemos
{
    delegate double CalculatorDelegate(double d1, double d2);

    class AnonymousDelegateDemo
    {
        static void Main(string[] args)
        {
            //using Inline function
            double d1 = 302.514, d2 = 521.01;
            DoTask(delegate (double a1, double a2) { return (a1 + a2); }, d1, d2);  //Pass Any Function as a parameter

            //Using Lamda Expressions: Any keyword is not required
            DoTask((a1, a2) => (a1 + a2), d1, d2);  //Pass Any Function as a parameter

            //Using Statement Lamda
            DoTask((a1, a2) => {Console.WriteLine("Hello"); return (a1 + a2); }, d1, d2);  //Pass Any Function as a parameter
        }

        static void DoTask(CalculatorDelegate task, double d1, double d2)
        {
            task(d1, d2);
        }
    }
}
