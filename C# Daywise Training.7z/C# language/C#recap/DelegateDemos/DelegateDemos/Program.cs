﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemos
{
    public delegate void MyDel1();

    class Program
    {
        static void Abc()
        {
            Console.WriteLine("Hello from ABC");
        }

        static void Main(string[] args)
        {
            //First Way
            Abc();

            //Second Way
            Action ad1 = new Action(Abc);

            ad1();     //or ad.Invoke();

            //Third Way
            MyDel1 d1 = new MyDel1(Abc);
            d1();

            Console.ReadKey();
        }
    }
}
