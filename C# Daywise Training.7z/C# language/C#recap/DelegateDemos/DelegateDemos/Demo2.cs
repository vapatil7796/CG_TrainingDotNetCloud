﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemos
{
    class Calculator
    {
        public double Add(double d1, double d2)
        {
            return d1 + d2;
        }
        public double Sub(double d1, double d2)
        {
            return d1 - d2;
        }
    }

    class Demo2
    {
        delegate double CalculatorDelegate(double d1, double d2);

        static void Main(string[] args)
        {
            Console.WriteLine("This is second demo");

            Calculator calculator = new Calculator();

            ////singlecast delegate using
            //CalculatorDelegate calculatorDelegate = new CalculatorDelegate(calculator.Add);
            //calculatorDelegate(15.4,52.48);

            ////Multicast delegate using
            //calculatorDelegate = new CalculatorDelegate(calculator.Add);
            //calculatorDelegate += new CalculatorDelegate(calculator.Sub);  //called as Method Chaining
            //calculatorDelegate(500, 200.00);

            //calculatorDelegate -= new CalculatorDelegate(calculator.Add);  //We are removing Add refenece from the output
            //calculatorDelegate(500, 200.00);

            ////NEW METHOD
            //CalculatorDelegate del1 = new CalculatorDelegate(calculator.Add);
            //CalculatorDelegate del2 = new CalculatorDelegate(calculator.Sub);

            //CalculatorDelegate mDel = (CalculatorDelegate)MulticastDelegate.Combine(del1, del2);
            //mDel(15.4, 52.48);
            //CalculatorDelegate newDel = (CalculatorDelegate)MulticastDelegate.Remove(mDel, del1);
            //newDel(15.4, 52.48);

            //double d1 = 302.514, d2 = 521.01;
            //DoTask(calculator.Add, d1, d2);  //Pass Any Function as a parameter

        }
        static void DoTask( CalculatorDelegate task,double d1,double d2)
        {
            task(d1, d2);
        }

    }
}
