﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

//Added
using EMS_Entities;
using UserDefinedAttributes;

namespace AttributesDemo
{
    class Program
    {
        //[Obsolete("This is too old functionality. Use M2 instead!", true)]
        //static void M1()
        //{
        //    Console.WriteLine("This is functionality to send Indian Post mail...");
        //}

        //static void M2()
        //{
        //    Console.WriteLine("This is functionality to send Email...");
        //}

        static void Main(string[] args)
        {
            //M2();

            //Assembly asm = Assembly.LoadFrom("ababjeq/EMS_Entities.dll");
            //Type t = asm.GetType("EMS_Entities.Employee");
            //DeveloperInfoAttribute dia = (DeveloperInfoAttribute)Attribute.GetCustomAttribute(t, typeof(DeveloperInfoAttribute));

            Console.WriteLine("For printing single developer name i.e for Manager class");
            DeveloperInfoAttribute dia = (DeveloperInfoAttribute)Attribute.GetCustomAttribute(typeof(Manager), typeof(DeveloperInfoAttribute));

            Console.WriteLine(dia.DeveloperName);

            Console.WriteLine("\nFor printing multiple developer name i.e for Employee class");
            DeveloperInfoAttribute[] dia2 = (DeveloperInfoAttribute[])Attribute.GetCustomAttributes(typeof(Employee), typeof(DeveloperInfoAttribute));

            foreach (var item in dia2)
            {
                Console.WriteLine(item.DeveloperName);
            }

            Console.WriteLine("\nFor printing Method's multiple developer name i.e for Employee class");
            MethodBase method = typeof(Employee).GetMethod("M1");
            DeveloperInfoAttribute dia3 = (DeveloperInfoAttribute)method.GetCustomAttribute(typeof(DeveloperInfoAttribute), true);
            Console.WriteLine(dia3.DeveloperName);

            Console.ReadKey();
        }
    }
}
