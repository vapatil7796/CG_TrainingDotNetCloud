﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserDefinedAttributes;

namespace EMS_Entities
{
    [DeveloperInfo("Gauri")]
    [DeveloperInfo("Mahesh")]
    [ProjectInfo("EmpManagerSystem", "Vishal")]
    public class Employee
    {
        [DeveloperInfo("Ramesh")]
        public void M1()
        {

        }
    }
}
