﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApp
{
    class Program
    {
        static void Main(string[] args)
        {
            BankAccount bankAccount = new BankAccount();
            Console.WriteLine("*************Banking App*************");
            do
            {
                Console.WriteLine("1. Deposit Money");
                Console.WriteLine("2. Withdraw Money");
                Console.WriteLine("Enter Your Choice: ");
                var choice = Convert.ToInt32(Console.ReadLine());
            }
            while (true);
            

        }
    }
}
