﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApp
{
    class BankAccount
    {
        public int AccNumber { get; set; }
        public double Balance { get; set; }

        public void Deposit()
        {
            Console.Write("Enter Amount you want to Deposit: ");
            double amt = Convert.ToDouble(Console.ReadLine());
            Balance = Balance + amt;
            Console.WriteLine($"updated balance is: {Balance}");
        }

        public void Withdraw()
        {
            Console.Write("Enter Amount you want to Deposit: ");
            double amt = Convert.ToDouble(Console.ReadLine());
            Balance = Balance - amt;
            Console.WriteLine($"updated balance is: {Balance}");
        }
    }
}
