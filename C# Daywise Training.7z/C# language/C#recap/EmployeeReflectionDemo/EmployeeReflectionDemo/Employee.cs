﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeReflectionDemo
{
    public class Employee
    {
        public int EmpID { get; set; }
        public string EmpName { get; set; }
        public double EmpSal { get; set; }
        public DateTime Joining { get; set; }

        public string GetEmpInfo()
        {
            return $"EmpID: {EmpID}, Name= {EmpName}, Salary= {EmpSal}, Joining= {Joining}";
        }

        public bool MinSalaryCheck(double minSal)
        {
            return EmpSal >= minSal;
        }
    }
}
