﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using UserDefinedAttributes;
using System.Reflection;

namespace GatherProjectInfo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter URL of your DLL file to gather Project Info: ");
            var str = Console.ReadLine();

            Assembly asm = Assembly.LoadFrom(str);
            //Type t = asm.GetType("EMS_Entities.Manager");
            Type[] t = asm.GetTypes();

            foreach (var item in t)
            {
                Console.WriteLine("\n"+item);
                ProjectInfoAttribute[] dia = (ProjectInfoAttribute[])Attribute.GetCustomAttributes(item, typeof(ProjectInfoAttribute));

                foreach (var item1 in dia)
                {
                    Console.WriteLine(item1.ProjectName + " " + item1.ManagerName);
                }
            }
            //ProjectInfoAttribute[] dia = (ProjectInfoAttribute[])Attribute.GetCustomAttributes(t, typeof(ProjectInfoAttribute));

            //foreach (var item in dia)
            //{
            //    Console.WriteLine(item.ProjectName + " " + item.ManagerName);
            //}
            
        }
    }
}
