﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace reflectionTest
{
    class Program
    {
        static void Main(string[] args)
        {
            //Extract metadata of Assembly - ReflectionDemo.dll, DelegateDemos.exe
            Console.Write("Enter Path of any assembly: ");
            string pathOfAssembly = Console.ReadLine();
            Assembly asm = Assembly.LoadFrom(pathOfAssembly);
            Type[] types = asm.GetTypes();

            foreach (Type item in types)
            {
                Console.WriteLine(item.Name + " " + item.FullName);
                MethodInfo[] methodInfos = item.GetMethods();

                Console.WriteLine("\t\t\t\tMethods From "+item.Name);

                foreach (MethodInfo mi in methodInfos)  //Methods Info
                {
                    //Console.WriteLine(mi.ReturnType + " " + mi.Name + " " + "(" + ")");
                    Console.WriteLine(mi.ToString());
                }

                Console.WriteLine("\t\t\t\tProperties From " + item.Name);

                PropertyInfo[] props = item.GetProperties();  //Property Info
                foreach (PropertyInfo pi in props)
                {
                    Console.WriteLine(pi.ToString());
                }

                FieldInfo[] flds = item.GetFields();
                foreach (FieldInfo pi in flds)
                {
                    Console.WriteLine(pi.ToString());
                }
            }

            Console.ReadKey();
        }
    }
}
