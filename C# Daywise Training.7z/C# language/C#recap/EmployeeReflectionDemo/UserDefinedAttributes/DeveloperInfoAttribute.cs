﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserDefinedAttributes
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
    public class DeveloperInfoAttribute : Attribute
    {
        public string DeveloperName { get; set; }

        public DeveloperInfoAttribute(string devName)
        {
            DeveloperName = devName;
        }
    }

    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
    public class ProjectInfoAttribute : Attribute
    {
        public string ProjectName { get; set; }
        public string ManagerName { get; set; }

        public ProjectInfoAttribute(string prName, string manName)
        {
            ProjectName = prName;
            ManagerName = manName;
        }
    }
}
