﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DRMSException
{
    public class DealerException : ApplicationException
    {
        public DealerException()
        {

        }
        public DealerException(string Message) : base(Message)
        {

        }
    }
}
