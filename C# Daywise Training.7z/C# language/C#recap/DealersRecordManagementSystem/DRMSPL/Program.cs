﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DRMSEntity;
using DRMSException;
using DRMSBLL;

namespace DRMSPL
{
    class Program
    {
        static DealerBLL dealerBLL = new DealerBLL();

        static void Main(string[] args)
        {
            byte choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice: ");

                bool checkChoice;
                checkChoice = byte.TryParse(Console.ReadLine(), out choice);
                if (!checkChoice)
                {
                    Console.WriteLine("Invalid Input ");
                }
                //int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddDealerPL();
                        break;
                    case 2:
                        GetAllDealersPL();
                        break;
                    case 3:
                        SearchByProductCategoryPL();
                        break;
                    case 4:
                        SerializeDealersPL();
                        break;
                    case 5:
                        DeserializeDealersPL();
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != 0);

        }

        private static void PrintMenu()
        {
            Console.WriteLine("\n**************Dealer record Management System********************");
            Console.WriteLine("1. Add Dealer");
            Console.WriteLine("2. List All Dealers");
            Console.WriteLine("3. Search Dealer by Product Category");
            Console.WriteLine("4. Serialize All Dealers");
            Console.WriteLine("5. Deserialize All Dealers");
            Console.WriteLine("\n*****************************************************************");
        }

        private static void AddDealerPL()
        {
            try
            {
                //Accept input from User 
                Console.Write("Enter Dealer ID: ");
                string DealerId = Console.ReadLine();
                Console.Write("Enter Dealer Name: ");
                string DealerName = Console.ReadLine();
                Console.Write("Enter Address: ");
                string Address = Console.ReadLine();
                Console.Write("Enter Email Address: ");
                string EmailAddress = Console.ReadLine();
                Console.Write("Enter Phone Number: ");
                string PhoneNumber = Console.ReadLine();
                Console.Write("Enter Dealer Status: ");
                bool DealerStatus = bool.Parse(Console.ReadLine());
                Console.Write("Enter Product Category: ");
                string ProductCategory = Console.ReadLine();

                //Pass input to Create new Object
                Dealer newDealer = new Dealer();
                newDealer.DealerId = DealerId;
                newDealer.Name = DealerName;
                newDealer.Address = Address;
                newDealer.EmailAddress = EmailAddress;
                newDealer.PhoneNumber = PhoneNumber;
                newDealer.DealerStatus = DealerStatus;
                newDealer.ProductCategory = ProductCategory;

                bool isNewDealerAdded = dealerBLL.AddDealerBLL(newDealer);

                if (isNewDealerAdded)
                {
                    Console.WriteLine("Dealer Added Successfully.");
                }
                else
                {
                    Console.WriteLine("Failed to Add Dealer.");
                }
            }
            catch (DealerException exception)
            {
                Console.WriteLine("Exception Occured " + exception.Message);
            }
            catch (Exception exception)
            {
                Console.WriteLine("Exception Occured " + exception.Message);
            }
        }

        private static void GetAllDealersPL()
        {
            List<Dealer> DealerList = dealerBLL.GetAllDealersBLL();
            //Console.WriteLine("-----------------------------------------------------------------");
            //Console.WriteLine("ID" + "\t" + "Name" + "\t" + "Address" + "\t" + "Email" + "\t" + "Phone" + "\t" + "Status" + "\t" + "Category");
            //Console.WriteLine("-----------------------------------------------------------------");

            //foreach (Dealer dealer in DealerList)
            //{
            //    Console.WriteLine(dealer.DealerId+"\t"+dealer.Name + "\t" +dealer.Address + "\t" +dealer.EmailAddress + "\t" +dealer.PhoneNumber + "\t" +dealer.DealerStatus + "\t" +dealer.ProductCategory);
            //}
            //Console.WriteLine("-----------------------------------------------------------------");
            PrintList(DealerList);
        }

        private static void SearchByProductCategoryPL()
        {
            Console.Write("Enter the Product Category: ");
            string ProductCategory = Console.ReadLine();

            List<Dealer> SearchedDealers = dealerBLL.SearchByProductCategoryBLL(ProductCategory);
            //Console.WriteLine("-----------------------------------------------------------------");
            //Console.WriteLine("ID" + "\t" + "Name" + "\t" + "Address" + "\t" + "Email" + "\t" + "Phone" + "\t" + "Status" + "\t" + "Category");
            //Console.WriteLine("-----------------------------------------------------------------");

            //foreach (Dealer dealer in SearchedDealers)
            //{
            //    Console.WriteLine(dealer.DealerId + "\t" + dealer.Name + "\t" + dealer.Address + "\t" + dealer.EmailAddress + "\t" + dealer.PhoneNumber + "\t" + dealer.DealerStatus + "\t" + dealer.ProductCategory);
            //}
            //Console.WriteLine("-----------------------------------------------------------------");
            PrintList(SearchedDealers);
        }

        private static void SerializeDealersPL()
        {
            if (dealerBLL.SerializeDealersBLL())
            {
                Console.WriteLine("Dealer details serialize Successfully...");
            }
            else
            {
                Console.WriteLine("Failed to serialize Dealer details!");
            }
        }

        private static void DeserializeDealersPL()
        {
            List<Dealer> DeserializedDealers;
            DeserializedDealers = dealerBLL.DeserializeDealersBLL();
            Console.WriteLine("\t\t\tDESERIALIZED DATA:");
            //Console.WriteLine("-----------------------------------------------------------------");
            //Console.WriteLine("ID" + "\t" + "Name" + "\t" + "Address" + "\t" + "Email" + "\t" + "Phone" + "\t" + "Status" + "\t" + "Category");
            //Console.WriteLine("-----------------------------------------------------------------");

            //foreach (Dealer dealer in DeserializedDealers)
            //{
            //    Console.WriteLine(dealer.DealerId + "\t" + dealer.Name + "\t" + dealer.Address + "\t" + dealer.EmailAddress + "\t" + dealer.PhoneNumber + "\t" + dealer.DealerStatus + "\t" + dealer.ProductCategory);
            //}
            //Console.WriteLine("-----------------------------------------------------------------");
            PrintList(DeserializedDealers);
        }

        private static void PrintList(List<Dealer> RequiredList)
        {
            Console.WriteLine("-----------------------------------------------------------------");
            Console.WriteLine("ID" + "\t" + "Name" + "\t" + "Address" + "\t" + "Email" + "\t" + "Phone" + "\t" + "Status" + "\t" + "Category");
            Console.WriteLine("-----------------------------------------------------------------");

            foreach (Dealer dealer in RequiredList)
            {
                Console.WriteLine(dealer.DealerId + "\t" + dealer.Name + "\t" + dealer.Address + "\t" + dealer.EmailAddress + "\t" + dealer.PhoneNumber + "\t" + dealer.DealerStatus + "\t" + dealer.ProductCategory);
            }
            Console.WriteLine("-----------------------------------------------------------------");
        }
    }
}
