﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DRMSEntity;
using DRMSException;
using DRMSDAL;

namespace DRMSBLL
{
    public class DealerBLL
    {
        DealerDAL dealerDAL = new DealerDAL();

        public bool AddDealerBLL(Dealer newDealer)
        {
            bool isDealerAdded = false;

            if (ValidateDealer(newDealer))
            {
                isDealerAdded = dealerDAL.AddDealerDAL(newDealer);
            }

            return isDealerAdded;
        }

        private static bool ValidateDealer(Dealer dealer)
        {
            return true;
        }

        public List<Dealer> GetAllDealersBLL()
        {
            return dealerDAL.GetAllDealersDAL();
        }

        public List<Dealer> SearchByProductCategoryBLL(string ProductCategory)
        {
            return dealerDAL.SearchByProductCategoryDAL(ProductCategory);
        }

        public bool SerializeDealersBLL()
        {
            return dealerDAL.SerializeDealersDAL();
        }

        public List<Dealer> DeserializeDealersBLL()
        {
            return dealerDAL.DeserializeDealersDAL();
        }
    }
}
