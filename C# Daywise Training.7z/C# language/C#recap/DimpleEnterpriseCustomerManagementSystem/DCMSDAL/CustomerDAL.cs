﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using DCMSEntity;
using DCMSException;

namespace DCMSDAL
{
    public class CustomerDAL
    {
        static List<Customer> customerList = new List<Customer>();

        public bool AddCustomerDAL(Customer customer)
        {
            bool isCustomerAdded = false;
            try
            {
                customerList.Add(customer);
                isCustomerAdded = true;
            }
            catch(CustomerException exception)
            {
                Console.WriteLine(exception.Message);
            }

            return isCustomerAdded;
        }

        public List<Customer> GetAllCustomersDAL()
        {
            return customerList;
        }

        public List<Customer> SearchByCustomerCityDAL(string City)
        {
            return customerList.FindAll(customer => customer.City.Equals(City));
        }

        public bool SerializeCustomersDAL()
        {
            bool areCustomersSerialized = false;

            try
            {
                FileStream fileStream = new FileStream("CustomersInfo.ser", FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fileStream, customerList);
                fileStream.Close();
                areCustomersSerialized = true;
            }
            catch (SystemException exception)
            {
                throw new CustomerException(exception.Message);
            }

            return areCustomersSerialized;
        }

        public List<Customer> DeserializeCustomersDAL()
        {
            List<Customer> DeserializedCustomers;
            try
            {
                FileStream fileStream = new FileStream("CustomersInfo.ser", FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                DeserializedCustomers = (List<Customer>)binaryFormatter.Deserialize(fileStream);
                fileStream.Close();
            }
            catch (SystemException exception)
            {
                throw new CustomerException(exception.Message);
            }
            return DeserializedCustomers;
        }
    }
}
