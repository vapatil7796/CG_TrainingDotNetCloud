﻿using System.Collections.Generic;
using System.Text;
using DCMSEntity;
using DCMSDAL;
using System.Text.RegularExpressions;
using System;
using DCMSException;

namespace DCMSBLL
{
    public class CustomerBLL
    {
        static CustomerDAL customerDAL = new CustomerDAL();

        public bool AddCustomerBLL(Customer customer)
        {
            bool isCustomerAdded = false;
            if (ValidateCustomer(customer))
            {
                isCustomerAdded = customerDAL.AddCustomerDAL(customer);
            }

            return isCustomerAdded;
        }

        private static bool ValidateCustomer(Customer customer)
        {
            bool validCustomer = true;
            StringBuilder message = new StringBuilder();

            //Customer ID validation
            if ((customer.CustomerID == string.Empty || customer.CustomerID == null) || !Regex.IsMatch(customer.CustomerID, @"C[0-9]{4}$"))
            {
                message.Append(Environment.NewLine + "Invalid Customer Id");
                validCustomer = false;
            }

            //Customer Name Validation
            if (customer.CustomerName == string.Empty || customer.CustomerName == null)
            {
                message.Append(Environment.NewLine + "Invalid Customer Name");
                validCustomer = false;
            }

            //Address Validation
            if (customer.Address == string.Empty || customer.Address == null)
            {
                message.Append(Environment.NewLine + "Invalid Address");
                validCustomer = false;
            }

            //City Validation
            if (customer.City == string.Empty || customer.City == null)
            {
                message.Append(Environment.NewLine + "Invalid City");
                validCustomer = false;
            }

            //Contact Number validation
            if ((customer.Contact == string.Empty || customer.Contact == null) || !Regex.IsMatch(customer.Contact, @"[7,8,9][0-9]{9}$"))
            {
                message.Append(Environment.NewLine + "Invalid Customer Id");
                validCustomer = false;
            }

            //Email validation
            if ((customer.Email == string.Empty || customer.Email == null) || !Regex.IsMatch(customer.Email,
                @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z"))
            {
                message.Append(Environment.NewLine + "Invalid Email Address");
                validCustomer = false;
            }

            if (validCustomer == false)
            {
                Console.WriteLine("Validation Error: "+message);
            }

            return validCustomer;
        }

        public List<Customer> GetAllCustomersBLL()
        {
            return customerDAL.GetAllCustomersDAL();
        }

        public List<Customer> SearchByCustomerCityBLL(string City)
        {
            return customerDAL.SearchByCustomerCityDAL(City);
        }

        public bool SerializeCustomersBLL()
        {
            return customerDAL.SerializeCustomersDAL();
        }

        public List<Customer> DeserializeCustomersBLL()
        {
            return customerDAL.DeserializeCustomersDAL();
        }
    }
}
