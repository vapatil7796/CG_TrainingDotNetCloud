﻿using System;
using System.Collections.Generic;
using DCMSEntity;
using DCMSBLL;

namespace DCMSPL
{
    class Program
    {
        static CustomerBLL customerBLL = new CustomerBLL();

        static void Main(string[] args)
        {
            byte choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice: ");

                bool checkChoice;
                checkChoice = byte.TryParse(Console.ReadLine(), out choice);
                if (!checkChoice)
                {
                    Console.WriteLine("Invalid Input ");
                }
                switch (choice)
                {
                    case 1:
                        AddCustomerPL();
                        break;
                    case 2:
                        GetAllCustomersPL();
                        break;
                    case 3:
                        SearchByCustomerCityPL();
                        break;
                    case 4:
                        SerializeCustomersPL();
                        break;
                    case 5:
                        DeserializeCustomersPL();
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != 0);
        }

        private static void PrintMenu()
        {
            Console.WriteLine("\n**************Dealer record Management System********************");
            Console.WriteLine("1. Add Customer");
            Console.WriteLine("2. List All Customers");
            Console.WriteLine("3. Search Customer by City");
            Console.WriteLine("4. Serialize All Customers");
            Console.WriteLine("5. Deserialize All Customers");
            Console.WriteLine("\n*****************************************************************");
        }

        private static void AddCustomerPL()
        {
            Customer customer = new Customer();

            Console.Write("Enter Customer ID: ");
            customer.CustomerID = Console.ReadLine();
            Console.Write("Enter Customer Name: ");
            customer.CustomerName = Console.ReadLine();
            Console.Write("Enter Address: ");
            customer.Address = Console.ReadLine();
            Console.Write("Enter City: ");
            customer.City = Console.ReadLine().ToUpper();
            Console.Write("Contact Number: ");
            customer.Contact = Console.ReadLine();
            Console.Write("Enter Email ID: ");
            customer.Email = Console.ReadLine();

            var isCustomerAdded = customerBLL.AddCustomerBLL(customer);
            if (isCustomerAdded == true)
            {
                Console.WriteLine("Customer Added Successfully...");
            }
            else
            {
                Console.WriteLine("Failed to add Customer");
            }
        }

        private static void GetAllCustomersPL()
        {
            List<Customer> customerList;
            customerList = customerBLL.GetAllCustomersBLL();

            //Console.WriteLine("---------------------------------------------------------------------------");
            //Console.WriteLine("ID" + "\t" + "Name" + "\t" + "Address" + "\t" + "City" + "\t" + "Phone" + "\t" + "Email");
            //Console.WriteLine("---------------------------------------------------------------------------");
            //foreach (Customer customer in customerList)
            //{
            //    Console.WriteLine(customer.CustomerID+"\t"+customer.CustomerName + "\t" +customer.Address + "\t" +customer.City + "\t" +customer.Contact + "\t" +customer.Email);
            //}
            //Console.WriteLine("---------------------------------------------------------------------------");
            PrintList(customerList);
        }

        private static void SearchByCustomerCityPL()
        {
            Console.Write("Enter the City: ");
            var City = Console.ReadLine().ToUpper();
            List<Customer> customerList;
            customerList = customerBLL.SearchByCustomerCityBLL(City);

            //Console.WriteLine("---------------------------------------------------------------------------");
            //Console.WriteLine("ID" + "\t" + "Name" + "\t" + "Address" + "\t" + "City" + "\t" + "Phone" + "\t" + "Email");
            //Console.WriteLine("---------------------------------------------------------------------------");
            //foreach (Customer customer in customerList)
            //{
            //    Console.WriteLine(customer.CustomerID + "\t" + customer.CustomerName + "\t" + customer.Address + "\t" + customer.City + "\t" + customer.Contact + "\t" + customer.Email);
            //}
            //Console.WriteLine("---------------------------------------------------------------------------");
            PrintList(customerList);
        }

        private static void SerializeCustomersPL()
        {
            if (customerBLL.SerializeCustomersBLL())
            {
                Console.WriteLine("Customer details serialize Successfully...");
            }
            else
            {
                Console.WriteLine("Failed to serialize Customer details!");
            }
        }

        private static void DeserializeCustomersPL()
        {
            List<Customer> customerList;
            customerList = customerBLL.DeserializeCustomersBLL();
            Console.WriteLine("\t\t\tDESERIALIZED DATA:");

            //Console.WriteLine("---------------------------------------------------------------------------");
            //Console.WriteLine("ID" + "\t" + "Name" + "\t" + "Address" + "\t" + "City" + "\t" + "Phone" + "\t" + "Email");
            //Console.WriteLine("---------------------------------------------------------------------------");
            //foreach (Customer customer in customerList)
            //{
            //    Console.WriteLine(customer.CustomerID + "\t" + customer.CustomerName + "\t" + customer.Address + "\t" + customer.City + "\t" + customer.Contact + "\t" + customer.Email);
            //}
            //Console.WriteLine("---------------------------------------------------------------------------");
            PrintList(customerList);
        }

        private static void PrintList(List<Customer> customerList)
        {
            Console.WriteLine("---------------------------------------------------------------------------");
            Console.WriteLine("ID" + "\t" + "Name" + "\t" + "Address" + "\t" + "City" + "\t" + "Phone" + "\t" + "Email");
            Console.WriteLine("---------------------------------------------------------------------------");
            foreach (Customer customer in customerList)
            {
                Console.WriteLine(customer.CustomerID + "\t" + customer.CustomerName + "\t" + customer.Address + "\t" + customer.City + "\t" + customer.Contact + "\t" + customer.Email);
            }
            Console.WriteLine("---------------------------------------------------------------------------");
        }
    }
}
