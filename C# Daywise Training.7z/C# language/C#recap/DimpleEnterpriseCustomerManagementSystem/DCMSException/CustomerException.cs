﻿using System;

namespace DCMSException
{
    public class CustomerException : ApplicationException
    {
        public CustomerException()
        {

        }

        public CustomerException(string Message) : base(Message)
        {

        }
    }
}
