﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OtherDemos
{
    //class for first Extension Method
    static class Int32Extensions
    {
        public static int Add(this int no, int x)
        {
            return no + x;
        }
    }

    //class for second Extension Method
    static class StringExtensions
    {
        public static string Greet(this string msg, string x)
        {
            return x + " " + msg;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //For Extension Method
            int no = 10;
            int res = no.Add(5);
            Console.WriteLine("Result is: " + res);

            //Another Extension Method
            string userName = "Harshal";
            string userGreeting = userName.Greet("Good Morning");
            Console.WriteLine(userGreeting);
        }


    }
}
