﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OtherDemos
{
    class Person
    {
        //There are some fields/ Properties
        public virtual void DoJob()
        {
            Console.WriteLine("Person is doing his/her job!");
        }
    }

    class Employee : Person
    {
        public override void DoJob()    //overriding: signature(Name + return type + args) is same for methods which are in hierarchy
        {
            Console.WriteLine("Employee is doing his/her job!");
        }
    }

    //main Program2.cs
    class Program2
    {
        static void Main(string[] args)
        {
            //OverridingDemo
            Person person = new Person();
            person.DoJob();

            Employee employee = new Employee();
            employee.DoJob();

            Person persons = new Employee();
            persons.DoJob();

        }
    }
}
