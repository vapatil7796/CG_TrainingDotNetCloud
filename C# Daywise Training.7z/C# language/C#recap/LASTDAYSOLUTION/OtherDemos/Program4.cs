﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OtherDemos
{
    class Program4
    {
        class MyCollection : IEnumerable
        {
            IEnumerator IEnumerable.GetEnumerator()
            {
                throw new NotImplementedException();
            }
        }

        class NumberRangeGenerator
        {
            //C#3.0 - Iterator Method

            //public static int[] GenerateNumbers(int minNum, int maxNum)
            //{
            //    int[] arr = new int[(maxNum - minNum )+ 1];
            //    for (int i = minNum, x = 0; i <= maxNum; i++, x++)
            //    {
            //        arr[x] = i;
            //    }
            //    return arr;
            //}

            public static IEnumerable GenerateNumbers(int minNum, int maxNum)
            {
                
                for (int i = minNum; i <= maxNum; i++)
                {
                    yield return i;
                }
                //return arr;
            }
        }

        static void Main(string[] args)
        {
            IEnumerable reqArr = NumberRangeGenerator.GenerateNumbers(5, 10);
            foreach (var item in reqArr)
            {
                Console.WriteLine(item);
            }

            //MyCollection obj = new MyCollection();
            //foreach (var item in obj)
            //{

            //}

            Console.ReadKey();
        }
    }
}
