﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OtherDemos
{
    class Program3
    {
        static void Main(string[] args)
        {
            //File Handling -File-System-Info Properties
            //Drive--> Directories--> Files

            DriveInfo[] driveInfos = DriveInfo.GetDrives();
            foreach (DriveInfo dInfo in driveInfos)
            {
                Console.WriteLine("Drive Name: " + dInfo.Name + "Volume Label: " + dInfo.VolumeLabel + "Drive Type: " + dInfo.DriveType);
                Console.WriteLine("\nDrive Name: " + dInfo.Name);

                DirectoryInfo directoryInfo = new DirectoryInfo(dInfo.Name);

                Console.WriteLine("\n\tList of Folders: ");
                DirectoryInfo[] dirs = directoryInfo.GetDirectories();
                Console.WriteLine("Total Folders in Drive are: " + dirs.Length);
                foreach (DirectoryInfo d in dirs)
                {
                    Console.WriteLine(d.Name);  //Temp
                    Console.WriteLine(d.FullName);  //c:\\..\..\
                }

                Console.WriteLine("\n\tList of Files");
                FileInfo[] files = directoryInfo.GetFiles();
                Console.WriteLine("Total Files in the Folder are: " + files.Length);
                foreach (FileInfo f in files)
                {
                    Console.WriteLine(f.Name);
                    Console.WriteLine(f.Extension);
                    Console.WriteLine(f.Length);
                }

            }
        }
    }
}
