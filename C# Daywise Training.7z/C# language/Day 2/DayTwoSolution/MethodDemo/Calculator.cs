﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodDemo
{
    class Calculator
    {
        //using 'in' parameter : by default if there is nothing other than 'in' in Method(int name) method


        //Using 'ref' parameter
        public void Swap(ref int a,ref int b)
        {
            int temp = a;
            a = b;
            b = temp;
            Console.WriteLine("Value of A:" + a);
            Console.WriteLine("value of B:" + b);
        }

        //Using 'out' parameter
        public void CalSqCube(int num,out int sq,out int cube)
        {
            sq = num * num;
            cube = num * num * num;
        }

        //Using 'params' parameter
        public int Add(params int[] a)
        {
            int sum = 0;
            for(int i = 0; i < a.Length; i++)
            {
                sum = sum + a[i];
            }
            return sum;
        }


    }
}
