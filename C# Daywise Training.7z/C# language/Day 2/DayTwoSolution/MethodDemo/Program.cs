﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator calculator = new Calculator();

            //Using 'ref' parameter
            int x = 100, y = 200;
            calculator.Swap(ref x, ref y);
            Console.WriteLine("Value of X:" + x);
            Console.WriteLine("value of Y:" + y);

            //Using 'out' parameter
            int square, cube;
            calculator.CalSqCube(5, out square, out cube);
            Console.WriteLine("Square is:" + square);
            Console.WriteLine("cube is:" + cube);

            //Using 'params' parameter
            Console.WriteLine("Two parameters Addition: " + calculator.Add(10,20));
            Console.WriteLine("Three parameters Addition: " + calculator.Add(10,20,30));
            Console.WriteLine("Multiple parameters Addition: " + calculator.Add(10, 20,30,50,80,60));

            Console.ReadLine();
        }
    }
}
