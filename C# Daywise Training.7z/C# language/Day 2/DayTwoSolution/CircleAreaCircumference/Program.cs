﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircleAreaCircumference
{
    class Program
    {
        static void Main(string[] args)
        {
            Circle circle = new Circle();
            double area, circumference;
            circle.AreaCircum(3.2, out area, out circumference);

            Console.WriteLine("Area: " + area);
            Console.WriteLine("Circumference: " + circumference);

            Console.ReadLine();
        }
    }
}
