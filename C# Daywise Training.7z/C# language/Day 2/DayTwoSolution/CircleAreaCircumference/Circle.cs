﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircleAreaCircumference
{
    class Circle
    {
        public void AreaCircum(double rad,out double area,out double circum)
        {
            area = 3.142 * rad * rad;
            circum = 2 * 3.142 * rad;
        }
    }
}
