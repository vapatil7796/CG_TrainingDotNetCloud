﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Functions
{
    class Reverse
    {
        public string ReverseStr(string name)
        {
            string reverse = "";
            int Length = 0;
            Length = name.Length - 1;   //calculate the length of the string Name
            while (Length >= 0)
            {
                reverse = reverse + name[Length];
                Length--;
            }
            return reverse;
        }
    }
}
