﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Functions
{
    class FactorialClass
    {
        public int Factorial(int num)
        {
            int fact = 1;
            for(int i=num; i >= 1; i--)
            {
                fact = fact * i;
            }
            return fact;
        }
    }
}
