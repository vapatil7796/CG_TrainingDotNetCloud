﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Functions
{
    class NumNature
    {
        public void NumType(int num)
        {
            if (num < 0)
                Console.WriteLine("Entered Number is Negative.");
            else if (num == 0)
                Console.WriteLine("Entered Number is Zero.");
            else
                Console.WriteLine("Entered number is positive.");
        }
    }
}
