﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Functions
{
    class Program
    {
        static void Main(string[] args)
        {
            int k=0;

            //Factorial Function
            FactorialClass factorialClass = new FactorialClass();
            int n = 9, factorial;
            factorial = factorialClass.Factorial(n);
            Console.WriteLine("factorial of number is:" + factorial);

            //Number is +ve, -ve or zero
            NumNature numNature = new NumNature();
            numNature.NumType(-88);

            //Customized power of the number
            PowerNum powerNum = new PowerNum();
            double power = powerNum.PowerN(3.2, 6);
            Console.WriteLine("The power of 3.2 with respect to 6 is: " + power);

            //First Pattern
            for(int i = 1; i <= 5; i++)
            {
                for(int j = 1; j <= i; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }

            //Second Pattern
            for(int i = 1; i <= 5; i++)
            {
                for(int j=1;j<=5-i ;j++)
                {
                    Console.Write(" ");
                }
                for (int j = 1; j <= i; j++)
                {
                    Console.Write("* ");
                }
                Console.WriteLine();
            }

            //Reverse String
            Reverse reverse = new Reverse();
            string name = "Vishal";
            string reverseName = reverse.ReverseStr(name);

            Console.WriteLine("Reverse word is: {0}", reverseName); // Display the reverse word

            Console.ReadLine();
        }
    }
}
