﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Functions
{
    class PowerNum
    {
        public double PowerN(double num1,int num2)
        {
            double result = 1;
            for(int i = 1; i <= num2; i++)
            {
                result = result * num1;
            }
            return result;
        }
    }
}
