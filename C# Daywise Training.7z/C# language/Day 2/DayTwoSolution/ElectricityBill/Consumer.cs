﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElectricityBill
{
    class Consumer
    {
        public double CalBill(int units)
        {
            double billAmt = 0;

            //Bill Generation on Units
            if (units < 100)
            {
                billAmt = 0.4 * units;
            }
            else if ((units >= 100) && (units < 300))
            {
                billAmt = 0.6 * units;
            }
            else if (units >= 300)
            {
                billAmt = 0.8 * units;
         
            }


            if (billAmt > 400)
            {
                billAmt = billAmt + 0.15 * billAmt;
            }
            billAmt = billAmt + 50;

            return billAmt;
        }

    }
}
