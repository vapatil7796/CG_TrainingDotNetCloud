﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElectricityBill
{
    class Program
    {
        static void Main(string[] args)
        {
            Consumer consumer = new Consumer();
            int units = 550;
            double finalBill = consumer.CalBill(units);
            

            Console.WriteLine("Your Electricity Bil: " + finalBill);

            Console.ReadLine();
        }
    }
}
