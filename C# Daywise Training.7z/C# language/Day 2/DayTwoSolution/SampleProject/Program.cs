﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleProject
{
    class Program
    {
        static void Main(string[] args)
        {
            //Sbyte
            sbyte num1 = 127;
            Console.WriteLine(num1);

            //Byte
            byte num2 =255;
            Console.WriteLine(num2);

            //Char
            char gender = 'M';  //Check
            Console.WriteLine(gender);

            //Short
            short loanDeduction = -256;
            Console.WriteLine(loanDeduction);

            //UShort
            ushort balanceAmount = 8888;
            Console.WriteLine(balanceAmount);

            //Int
            int smallCompanyProfit = -12414125;
            Console.WriteLine(smallCompanyProfit);

            //UInt
            uint medCompanyProfit = 255544852;
            Console.WriteLine(medCompanyProfit);

            //Long
            long richManBalance = 5444852114544748554;
            Console.WriteLine(richManBalance);

            //ULong
            ulong worldBankBalance = 184467448544477615;
            Console.WriteLine(worldBankBalance);

            //**************Implicit and Explicit Conversion**************

            byte b = 127;
            int a = b;    //Implicit Conversion
            Console.WriteLine(a);

            int k = 200;
            double o = k;    //Implicit Conversion
            Console.WriteLine(o);

            double d = 100.27;
            int p = (int)d;   //Explicit conversion or Typecasting
            Console.WriteLine(p);

            //***************Boxing and Unboxing****************

            float f = 10.5f;
            //The following line boxes f
            object o1 = f;
            Console.WriteLine(o1);

            int i = 123;
            object o2 = i;
            int j = (int)o2;
            Console.WriteLine(j);

        }
    }
}
