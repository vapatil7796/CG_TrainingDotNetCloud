﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NullableTypeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int id = 1;
            string name = null;

            Nullable<int> var1 = null;            //First type of Syntax
            Nullable<bool> var2 = null;

            bool? var3 = null;                    //Alternative syntax for Nullable<T> :Used widely because of shothand
            int? mobNumber = null;
            //int? mobNumber = 12541;

            if (mobNumber.HasValue)
            {
                Console.WriteLine(mobNumber);
            }
            else
            {
                Console.WriteLine("Mobile number is NULL or emty");
            }

            //DOC checking opcodes
            
            //First
            int? c = null;

            // d = c, if c is not null, d = -1 if c is null.
            int d = c ?? -1;
            Console.WriteLine($"d is {d}");

            //Second
            //int? n = null;
            ////int m1 = n;    // Doesn't compile.
            //int n2 = (int)n; // Compiles, but throws an exception if n is null.
            //Console.WriteLine(n2);

            //Third
            int? a = 10;
            int? b = null;
            int? e = 10;
            a++;        // a is 11.
            a = a * c;  // a is 110.
            a = a + b;  // a is null.
            Console.WriteLine(a);

            Console.ReadLine();
        }
    }
}
