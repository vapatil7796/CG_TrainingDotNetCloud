﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Array declaration
            //There are multiple ways to declare an array

            //Demo 1: Single Dimensional array
            double[] salary = { 8000.32, 50000, 6200.03, 82000.62, 16083.30 };
            Console.WriteLine("Salaries of respective Employess :");
            for (int i = 0; i <= salary.Length - 1; i++)
            {
                Console.WriteLine(salary[i] + "\t");
            }
            Console.WriteLine("Max salary is: " + salary.Max());
            Console.WriteLine("Min Salary is: " + salary.Min());
            Console.WriteLine("Total Cost to the Company is: " + salary.Sum());
            Console.WriteLine();


            //Demo 2: Multidimensional Array
            int[,] empManager = new int[5, 2] { { 1050, 15 }, { 520, 3 }, { 1500, 25 }, { 263, 1 }, { 822, 10 } };
            Console.WriteLine("Employee ID's with their respective Manager ID's :");
            for(int i = 0; i < 5; i++)
            {
                for(int j = 0; j < 2; j++)
                {
                    if (j == 0)
                        Console.Write("Employee ID: " + empManager[i, j]+"\t");
                    else
                        Console.Write("Employee's Manager ID: " + empManager[i, j]);
                }
                Console.WriteLine();
            }

            //Demo 3: Jagged Array...."Pending"
            


            Console.ReadLine();
        }
    }
}
