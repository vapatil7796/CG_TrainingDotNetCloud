﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //object Creation: Constructor Called

            //Sachin
            Account sachinAccount = new Account(1,"Sachin",10000,"Mumbai");

            //Deposit
            Console.WriteLine("Enter the Amount you want to Deposit: ");
            double amt = Convert.ToDouble(Console.ReadLine());
            sachinAccount.Deposit(amt);  //3000
            Console.ReadLine();

            //Withdraw
            Console.WriteLine("Enter the Amount you want to Withdraw: ");
            amt = Convert.ToDouble(Console.ReadLine());
            sachinAccount.Withdraw(amt);
            Console.ReadLine();

            //Check Balace
            Console.WriteLine("To Check the Balance Press ENTER: ");
            Console.ReadLine();
            sachinAccount.CheckBalace();

            //************************SAURAV**************************

            //Saurav
            Account sauravAccount = new Account(2, "Saurav", 30000, "Kolkata");

            //Deposit
            Console.WriteLine("Enter the Amount you want to Deposit: ");
            amt = Convert.ToDouble(Console.ReadLine());
            sauravAccount.Deposit(amt);  //3000
            Console.ReadLine();

            //Withdraw
            Console.WriteLine("Enter the Amount you want to Withdraw: ");
            amt = Convert.ToDouble(Console.ReadLine());
            sauravAccount.Withdraw(amt);
            Console.ReadLine();

            //Check Balace
            Console.WriteLine("To Check the Balance Press ENTER: ");
            Console.ReadLine();
            sauravAccount.CheckBalace();
            Console.ReadLine();
        }
    }
}
