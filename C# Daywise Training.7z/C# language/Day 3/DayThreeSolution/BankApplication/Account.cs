﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApplication
{
    class Account
    {
        //Data Members
        int accountNumber;
        string accountHolderName;
        double balance;
        string branchName;

        //Initialize Data Members: Constructors
        //Default Constructors
        public Account()
        {
            accountNumber = 0;
            accountHolderName = "Guest";
            balance = 0;
            branchName = "Guest Branch Name";
        }

        //Parametrized Constructor
        public Account(int acnum,string name,double bal,string brname)
        {
            accountNumber = acnum;
            accountHolderName = name;
            balance = bal;
            branchName = brname;
        }

        //Member functions
        //Deposit
        public void Deposit(double amount)
        {
            balance = balance + amount;
            Console.WriteLine($"Balance After Deposit is {balance} of {accountHolderName}");
        }

        //Withdraw
        public void Withdraw(double amount)
        {
            balance = balance - amount;
            Console.WriteLine($"Balance After Withdraw is {balance} of {accountHolderName}");
        }

        //Balance Check
        public void CheckBalace()
        {
            Console.WriteLine($"Current Balance is {balance} of {accountHolderName}");
        } 

    }
}
