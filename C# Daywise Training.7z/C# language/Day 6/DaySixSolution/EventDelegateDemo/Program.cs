﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDelegateDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            BoilingPlant plant = new BoilingPlant();
            plant.onComplete += Shutdown;
            plant.onComplete += RingBell;

            plant.BoilWater();

            Console.ReadLine();
        }
        
        //Outside Main method
        static void RingBell() //Action for an Event of Boiling Water
        {
            Console.WriteLine("Bell Started Ringing...");
        }

        static void Shutdown() //Action for an Event of Boiling Water
        {
            Console.WriteLine("Shutting Down...");
        }

        static void SendMessage() //Action for an Event of Boiling Water
        {
            Console.WriteLine("Sending Notification Message...");
        }
    }
}
