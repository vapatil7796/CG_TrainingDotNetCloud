﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GarbageCollectionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"Allocated Memory: {GC.GetTotalMemory(true)}"); //Checkinh how much memory already allocated

            int[] arr = new int[100];    //Allocating Memory
            for(int i = 0; i < 100; i++)
            {
                arr[i] = i;
            }
            Console.WriteLine($"Allocated Memory: {GC.GetTotalMemory(false)}");
            arr = null;
            GC.Collect();
            Console.WriteLine($"Allocated Memory: {GC.GetTotalMemory(true)}");

            Demo demo1 = new Demo();    
            //use the demo1 object
            //call the other methods of d
            demo1.Dispose();  //object is destroyed

            using (Demo demo2 = new Demo())   //using keyword automatic called Dispose method: scope of demo2 is within the {...}
            {
                //use the demo2 object
                //call the other methods of d
            }

            Console.ReadLine();
        }
    }
}
