﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GarbageCollectionDemo
{
    class Demo : IDisposable
    {

        //Suppose unmanaged object ex.
        //FileHandler x;

        //Other Members

        public void Dispose()
        {
            GC.SuppressFinalize(this);  //We're saying to Garbage Collector that you need not to execute Finalize method
            GC.Collect();
            //Other clean up code here

            //Clean the x object
        }
    }
}
