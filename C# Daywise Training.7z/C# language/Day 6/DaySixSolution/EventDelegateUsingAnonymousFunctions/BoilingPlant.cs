﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EventDelegateUsingAnonymousFunctions
{
    //Deligate for Event occuring
    delegate void EventExecuter();

    class BoilingPlant
    {
        //created object of deligate and make it as a EVENT
        public event EventExecuter onComplete;  //because of public, we can access it in Main method as well

        //Member Functions
        public void BoilWater()
        {
            for (int i = 1; i <= 150; i++)
            {
                Console.WriteLine($"Temp: {i}");
                Thread.Sleep(20);
                if (i == 100)
                {
                    Console.WriteLine("Water boiled Successfully...");
                    //do necessary actions, hence this is an EVENT

                    onComplete?.Invoke();  //OR onCoplete();  
                    //?. NullCoalesc operator equivalent to if stmt: it runs if the object is not 'null'
                    break;
                }
            }
        }
    }
}
