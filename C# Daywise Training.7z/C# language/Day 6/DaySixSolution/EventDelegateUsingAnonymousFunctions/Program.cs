﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDelegateUsingAnonymousFunctions
{
    class Program
    {
        static void Main(string[] args)
        {
            BoilingPlant plant = new BoilingPlant();
            plant.onComplete += delegate()    //Anonymous Function using delegate keyword: return type must be same
            {
                Console.WriteLine("Shutting Down...");
            };

            plant.onComplete += delegate ()    //Anonymous Function using delegate keyword
            {
                Console.WriteLine("Bell Started Ringing...");
            };

            plant.BoilWater();

            Console.ReadLine();
        }
    }
}
