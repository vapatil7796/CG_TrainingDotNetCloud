﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorUsingDelegateDemo
{
    delegate int MyDelegate(int a, int b);  //Declaring Delegate, we can declare it inside class But then we've to call then that using class object

    class Calculator
    {
        //Member Functions
        public int Add(int x,int y)
        {
            return x + y;
        }

        public int Subtract(int x, int y)
        {
            return x - y;
        }
    }
}
