﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorUsingDelegateDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Creating Objects
            Calculator calculator = new Calculator();
            MyDelegate myDelegate1 = new MyDelegate(calculator.Add);  //Creating delegate object for Add()
            MyDelegate myDelegate2 = new MyDelegate(calculator.Subtract);  //Creating delegate object for Subtract()

            //Invoking the required Functions
            int sum = myDelegate1.Invoke(8, 2); //int sum = myDelegate(8,2);...second way
            int difference = myDelegate2.Invoke(10, 4);  //int difference = myDelegate(10,4);...second way

            //Printing Result
            Console.WriteLine($"Addition is: {sum}");
            Console.WriteLine($"Subtraction is: {difference}");

            Console.ReadLine();
        }
    }
}
