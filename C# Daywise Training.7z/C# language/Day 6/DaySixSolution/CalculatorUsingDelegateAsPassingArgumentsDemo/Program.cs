﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorUsingDelegateAsPassingArgumentsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Creating Objects
            Calculator calculator = new Calculator();
            MyDelegate myDelegate1 = new MyDelegate(calculator.Add);  //Creating delegate object for Add()
            MyDelegate myDelegate2 = new MyDelegate(calculator.Subtract);  //Creating delegate object for Subtract()

            //Passing Delegates to other Function to Get Result
            Executer(myDelegate1, 5, 4);
            Executer(myDelegate2, 10, 2);

            Console.ReadLine();
        }

        static void Executer(MyDelegate d,int input1,int input2)
        {
            int result = d.Invoke(input1, input2);
            Console.WriteLine($"Result of Arithmetic Operation is: {result}");
        }
    }
}
