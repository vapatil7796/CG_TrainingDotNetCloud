﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int s = 25;
                int[] ar = new int[5];
                for (int i = 0; i < 5; i++)
                {
                    Console.WriteLine("Enter a number: ");
                    int n = Convert.ToInt32(Console.ReadLine());
                    ar[i] = s / n;
                }
                for (int i = 0; i < 5; i++)
                {
                    Console.WriteLine($"Element in position {i} is {ar[i]}.");
                }
            }
            catch (FormatException ex)
            {
                Console.WriteLine("You made some typing mistakes, Please Enter proper values");
                Console.WriteLine(ex.Message);
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine("You are refering to an invalid position");
                Console.WriteLine(ex.Message);
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("Cannot Divide with Zero, Please provide non-zero value");
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("All other exceptions will be handled here.");
                Console.WriteLine(ex.Message);
            }
            finally  //Always run with or without Exceptions
            {
                //code cleanup actions
                Console.WriteLine("I am from finally block. I'll always run.");
            }

            Console.WriteLine("Program completed for Predefined Exceptions");
            Console.ReadLine();

            //For custom Exception
            Console.WriteLine("For Custom Exception class...");
            try
            {
                Console.WriteLine("Enter Name: ");
                string name = Console.ReadLine();
                if (name.Length < 3)
                    throw new InvalidNameException();

                Console.WriteLine("Enter Age: ");
                int age = Convert.ToInt32(Console.ReadLine());
                if (age < 1 || age > 120)
                    throw new InvalidAgeException();

                Console.WriteLine($"Your name is {name} and you are {age} years old.");
            }
            catch(InvalidNameException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (InvalidAgeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadLine();
        }
    }
}
