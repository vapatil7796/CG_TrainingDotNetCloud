﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingDemo
{
    class InvalidNameException:Exception    //Custom exception
    {
        private string msg = "Invalid Name value entered.";

        public override string Message
        {
            get { return msg; }
        }

        public override string ToString()
        {
            return this.GetType() + ", " + msg;
        }
    }
}
