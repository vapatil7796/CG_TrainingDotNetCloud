﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousMethodsAndLamdas
{
    class Program
    {
        delegate void MyDeligate(string str);
        delegate int CalculatorDelegate(int a, int b);

        static void Main(string[] args)
        {
            //Method 1 for named function
            MyDeligate d1 = new MyDeligate(Show);  //Named Function : new keyword is not mandatory
            d1.Invoke("Hello World!");

            //Method 12 for named function
            MyDeligate d2 = Show;  //Named Function : new keyword is not mandatory
            d2.Invoke("Hello World!");

            MyDeligate d3 = delegate (string str)//Anonymous Function
            {
                Console.WriteLine($"Message is: {str}");
            };
            d3.Invoke("Hello Vishal!");

            //Calculator Delegate using Named Function
            CalculatorDelegate c1 = Add;
            int sum1 = c1.Invoke(5, 6);
            Console.WriteLine("Sum is: "+sum1);

            //Calculator Delegate using Anonymous Function
            CalculatorDelegate c2 = delegate (int a,int b)
            {
                return a + b;
            };
            int sum2 = c2.Invoke(50, 6);
            Console.WriteLine("Sum is: " + sum2);

            //Calculator Delegate using Lamda Function [LATEST]
            CalculatorDelegate c3 = (a, b) => a + b;  //Lamda Expression  LHS: arguments => RHS: returning appropriate result 
            int sum3 = c3.Invoke(54, 64);
            Console.WriteLine("Sum is: " + sum3);

            MyDeligate d4 = (s) =>      //Lamda Function
            {
                //Your Code Here
                Console.WriteLine("Message using Lamda Function is: "+s);
            };
            d4.Invoke("This is Lamda Function.");

            Console.ReadLine();
        }

        //outside Main method
        static void Show(string message)
        {
            Console.WriteLine("Message is: "+message);
        }

        static int Add(int x, int y)
        {
            return x + y;
        }
    }
}
