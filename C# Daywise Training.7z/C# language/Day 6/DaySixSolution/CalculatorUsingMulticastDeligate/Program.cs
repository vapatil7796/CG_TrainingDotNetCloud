﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorUsingMulticastDeligate
{
    class Program
    {
        static void Main(string[] args)
        {
            //Creating Objects
            Calculator calculator = new Calculator();

            //Multicast Deligates using Method: 1
            MyDelegate d = new MyDelegate(calculator.Add);  //Creating delegate object for Add()
            d += new MyDelegate(calculator.Subtract);
            d += new MyDelegate(calculator.Multiply);
            d += new MyDelegate(calculator.Add);

            Executer(d, 6, 5);
            Console.ReadLine();

            //Multicast Deligates using Method: 2
            MyDelegate d1 = new MyDelegate(calculator.Add);
            MyDelegate d2 = new MyDelegate(calculator.Subtract);
            MyDelegate d3 = new MyDelegate(calculator.Multiply);

            MyDelegate delegates = (MyDelegate)Delegate.Combine(d1, d2, d3);

            Executer(delegates, 6, 5);

            Console.ReadLine();
        }

        static void Executer(MyDelegate d, int input1, int input2)
        {
            int result = d.Invoke(input1, input2);
            Console.WriteLine($"Result of Arithmetic Operation is: {result}");
        }
    }
}
