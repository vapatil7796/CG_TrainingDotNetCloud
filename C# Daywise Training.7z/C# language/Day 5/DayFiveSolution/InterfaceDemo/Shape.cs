﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    abstract class Shape        //Parent Class
    {
        public abstract void Draw();
    }

    interface IColorable        //Interface
    {
        void ApplyColor(string colorName);   //Public and Abstract method
        void RemoveColor();   //Public and Abstract method
    }

    class Circle : Shape, IColorable       //class class_name: parent_class_name, interface_name
    {
        public override void Draw()
        {
            Console.WriteLine("Drawing Circle");
        }

        public void ApplyColor(string colorName)
        {
            Console.WriteLine($"Applying {colorName} color to the circle.");
        }
        
        public void RemoveColor()
        {
            Console.WriteLine("Removing Color");
        }
    }
}
