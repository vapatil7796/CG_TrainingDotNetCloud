﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Shape shape = new Circle();
            Console.WriteLine("Using First Method:\n ");
            
            shape.Draw();
            IColorable colorable = shape as Circle;   //'Shape' ref variable is now pointing to 'IColorable'
            colorable.ApplyColor("Red");
            colorable.RemoveColor();

            Console.ReadLine();
            Console.WriteLine("Using Second Method:\n ");

            Circle circle = new Circle();   //Using only object of Child Class
            circle.ApplyColor("Red");
            circle.Draw();
            circle.RemoveColor();

            Console.ReadLine();
        }
    }
}
