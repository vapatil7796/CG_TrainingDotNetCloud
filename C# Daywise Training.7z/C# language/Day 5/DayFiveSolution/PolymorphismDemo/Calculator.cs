﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo
{
    class Calculator
    {
        public int Add(int x,int y)
        {
            return x + y;
        }

        public double Add(int x,double y)   //Overloading
        {
            return x + y;
        }

        public string Add(string x, string y)   //Overloading
        {
            return x + y;
        }

        public int Subtract(int x,int y)   
        {
            return x - y;
        }

        public double Subtract(int x,double y)   //Overloading
        {
            return x - y;
        }
    }
}
