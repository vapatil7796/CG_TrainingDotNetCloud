﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo
{
    abstract class Account   // Abstract class: Not allows Object Creation
    {
        //Data Members using Auto Implemented Property
        public int AccountNumber { get; set; }
        public string AccountName { get; set; }
        public double Balance { get; set; }

        //Member Functions
        public void Deposit(double amt)   //Deposit Function, we can't override because there's no 'virtual' keyword
        {
            this.Balance = this.Balance + amt;
            Console.WriteLine($"Amount {amt} is successfully deposited in your Account");
        }

        public abstract void Withdraw(double amt);

        public virtual void Accept()
        {
            Console.WriteLine("Enter Your Account Number: ");
            this.AccountNumber = Convert.ToInt32(Console.ReadLine());  //Accepting account no.

            Console.WriteLine("Enter Account Holder Name: ");
            this.AccountName = Console.ReadLine();  //Accepting Acc Holder name

            Console.WriteLine("Enter Your Account Balance: ");
            this.Balance = Convert.ToDouble(Console.ReadLine());  //Accepting balance
        }

        public virtual void Print()   //'virtual' keyword is used to tell Print() to open for Override
        {
            Console.WriteLine($"Account Number: {AccountNumber}");
            Console.WriteLine($"Account Holder Name: {AccountName}");
            Console.WriteLine($"Account Balance: {Balance}");
        }

    }

    class CurrentAccount : Account    //Child Class of Base class Account, using : operator
    {

        //Data Members using Auto Implemented Property
        public double OverdraftLimit { get; set; }
        public int TransactionLimit { get; set; }

        //Member Function
        public override void Print()   //Overriden function
        {
            base.Print();
            Console.WriteLine($"Overdraft Limit: {OverdraftLimit}");
            Console.WriteLine($"Transaction Limit: {TransactionLimit}");
        }

        public override void Accept()
        {
            base.Accept();
            Console.WriteLine("Enter the Overdraft Limit: ");
            this.OverdraftLimit = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter Transaction Limit: ");
            this.TransactionLimit = Convert.ToInt32(Console.ReadLine());
        }

        public override void Withdraw(double amt)
        {

        }
    }

    class SavingsAccount : Account    //Child Class of Base class Account, using : operator
    {
        //Data Members using Auto Implemented Property
        public bool IsSalaryAccount { get; set; }

        //Member Function
        public override void Print()    //Overriden function
        {
            base.Print();
            Console.WriteLine($"Salary Account: {IsSalaryAccount}");
        }

        public override void Accept()
        {
            base.Accept();
            Console.WriteLine("Is it a Salary Account (Y/N): ");
            string input = Console.ReadLine();
            this.IsSalaryAccount = (input == "Y") ? true : false;
        }

        public override void Withdraw(double amt)
        {

        }
    }

    class FixedAccount : Account    //Child Class of Base class Account, using : operator
    {
        //Data Members using Auto Implemented Property
        public int Duration { get; set; }
        public double InterestRate { get; set; }

        //Member Function
        public override void Print()    //Overriden function
        {
            base.Print();
            Console.WriteLine($"Deposit duration: {Duration}");
            Console.WriteLine($"Interest Rate: {InterestRate}");
        }

        public override void Accept()
        {
            base.Accept();
            Console.WriteLine("Enter Deposit Duration: ");
            this.Duration = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Interest Rate: ");
            this.InterestRate = Convert.ToDouble(Console.ReadLine());
        }

        public override void Withdraw(double amt)
        {
            
        }
    }

}
