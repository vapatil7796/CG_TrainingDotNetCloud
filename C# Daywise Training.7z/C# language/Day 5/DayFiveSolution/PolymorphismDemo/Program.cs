﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator calculator = new Calculator();   //Object Creation

            int sum1 = calculator.Add(4, 5);   //Calling Add(...) method
            double sum2 = calculator.Add(85, 2.67);   //Calling overloaded Add(...) method
            string sum3 = calculator.Add("Hello", " Vishal!");   //Calling overloaded Add(...) method

            //Printing Required Values
            Console.WriteLine(sum1); 
            Console.WriteLine(sum2) ;
            Console.WriteLine(sum3);


            //Now Overriding Starts
            Console.ReadLine();
            Console.WriteLine("Now Its Time for Overriding...");
            CurrentAccount currentAccount = new CurrentAccount();
            currentAccount.AccountNumber = 5001;
            currentAccount.AccountName = "Vishal";
            currentAccount.Balance = 30000;
            currentAccount.OverdraftLimit = 521000;
            currentAccount.TransactionLimit = 10000;

            currentAccount.Print();

            Console.ReadLine();
            //Console.WriteLine("Runtime Polymorphism...");
            Account account;
            Console.WriteLine("Which Type of Account you want to open? ");
            Console.WriteLine("1. Savings\n2. Current\n3. Fixed\n");
            int choice = Convert.ToInt32(Console.ReadLine());  //Accepting Choice from User
            if (choice == 1)
            {
                account = new SavingsAccount();
            }
            else if (choice == 2)
            {
                account = new CurrentAccount();
            }
            else
            {
                account = new FixedAccount();
            }

            account.Accept();  //To take values from User
            account.Print();  //To print all the values of respective User


            Console.ReadLine();
        }
    }
}
