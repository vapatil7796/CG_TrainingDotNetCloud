﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectAndMethodDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Both the syntaxes are Correct to initialize values 
            Student student1 = new Student {
                Id = 101,
                Name = "Vishal",   
                Mark = 89
            };            //Object Initializer without constructor

            var student2 = new Student() { Id = 102, Name = "Anil", Mark = 98 };
            //var is local scope, directly considers type from assigned values

            Console.WriteLine($"For First Student: ");
            Console.WriteLine($"Student ID: {student1.Id}");
            Console.WriteLine($"Student Name: {student1.Name}");
            Console.WriteLine($"Marks Scored: {student1.Mark}\n");

            Console.WriteLine($"For Second Student: ");
            Console.WriteLine($"Student ID: {student2.Id}");
            Console.WriteLine($"Student Name: {student2.Name}");
            Console.WriteLine($"Marks Scored: {student2.Mark}");

            Console.ReadLine();
        }
    }
}
