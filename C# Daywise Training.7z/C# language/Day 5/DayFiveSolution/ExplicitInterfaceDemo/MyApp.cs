﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplicitInterfaceDemo
{
    interface IDatabaseManager
    {
        void Connect();
    }
    interface INetworkManager
    {
        void Connect();
    }

    class MyApp : IDatabaseManager, INetworkManager
    {
        void IDatabaseManager.Connect()  //Implemented Interface Explicitly
        {
            Console.WriteLine("Database Connected.");
        }

        void INetworkManager.Connect()   //Implemented Interface Explicitly
        {
            Console.WriteLine("Network Connected.");
        }
    }
}
