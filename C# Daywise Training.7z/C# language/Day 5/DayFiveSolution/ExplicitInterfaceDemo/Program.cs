﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplicitInterfaceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            INetworkManager networkManager = new MyApp();  
            networkManager.Connect();

            IDatabaseManager databaseManager = new MyApp();
            databaseManager.Connect();

            Console.ReadLine();
            Console.WriteLine("Now Sealed Class...");
            Product product = new Product();
            product.Id = 25;
            product.Name = "Apple";
            product.Price = 165.65;

            Console.ReadLine();
        }
    }
}
