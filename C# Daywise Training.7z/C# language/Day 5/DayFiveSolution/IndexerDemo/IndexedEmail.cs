﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexerDemo
{
    class IndexedEmail
    {
        private string[] emails = new string[100];

        public string this[int index]       //Indexer Declaration: Use of this Indexer is mainly in Database section
        {
            get { return emails[index]; }
            set { emails[index] = value; }
        }
    }
}
