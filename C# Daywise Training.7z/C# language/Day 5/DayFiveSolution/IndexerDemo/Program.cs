﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexerDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            IndexedEmail indexedEmail = new IndexedEmail();
            indexedEmail[0] = "sonu@gmail.com";     //Object is behaving like an Array
            indexedEmail[1] = "aditya@gmail.com";
            indexedEmail[2] = "sekhar@gmail.com";

            Console.WriteLine(indexedEmail[0]);
            Console.WriteLine(indexedEmail[2]);
            Console.WriteLine(indexedEmail[1]);

            Console.ReadLine();
        }
    }
}
