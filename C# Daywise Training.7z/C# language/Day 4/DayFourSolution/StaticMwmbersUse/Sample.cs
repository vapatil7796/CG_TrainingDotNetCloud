﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticMwmbersUse
{
    class Sample
    {
        //Satic Data Members
        public static int count;
        //Static Constructor to initialize 'only static' variables: 
        //we use this to open new opportunities to get values from other source as well
        static Sample()
        {
            count = 1;
        }
        public void IncrementCount()
        {
            count = count + 1;
            Console.WriteLine("Current Value of count is:" + count);
        }

    }
}
