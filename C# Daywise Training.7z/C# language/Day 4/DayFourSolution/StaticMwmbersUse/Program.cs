﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticMwmbersUse
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample s1 = new Sample();
            s1.IncrementCount();

            Sample s2 = new Sample();
            s2.IncrementCount();
            
            Sample s3 = new Sample();
            s3.IncrementCount();

            Console.WriteLine(Sample.count);

            Console.ReadLine();
        }
    }
}
