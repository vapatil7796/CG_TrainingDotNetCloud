﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAppWithInheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            SavingAccount savingAccount = new SavingAccount(7, "Vishal", 10000, "Mumbai");
            savingAccount.Deposit(1000);
            savingAccount.Withdraw(2000);
            savingAccount.CheckBalance();
            savingAccount.FreeCC();

            CurrentAccount currentAccount = new CurrentAccount(23, "Anil", 20000, "Mumbai");
            currentAccount.Deposit(3000);
            currentAccount.Withdraw(33);
            currentAccount.CheckBalance();
            currentAccount.FreeInsurance();

            Console.ReadLine();
        }
    }
}
