﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAppWithInheritance
{
    class Account
    {
        //Data Members
        int accountNumber;
        protected double balance;
        protected string accountHolderName;
        string branchName;

        //Initialize Data Members: constructor
        //Default Constructor
        public Account()
        {
            accountNumber = 0;
            accountHolderName = "Guest";
            balance = 0;
            branchName = "Guest Branch Name";
        }
        //Parametrized constructor
        public Account(int acnum, string acname, double bal, string branch)
        {
            accountNumber = acnum;
            accountHolderName = acname;
            balance = bal;
            branchName = branch;
        }
        //Member Functions
        //Deposit
        public void Deposit(double amount)
        {
            balance = balance + amount;
            Console.WriteLine($"Account Balance After Deposit: {balance} of {accountHolderName}");
        }

        //Withdraw
        public virtual void Withdraw(double amount)     //Overriding using virtual keyword
        {
            balance = balance - amount;
            Console.WriteLine($"Account Balance After Withdraw: {balance} of {accountHolderName}");
        }

        //Check Balance
        public void CheckBalance()
        {
            Console.WriteLine($"Current Balance: {balance} of {accountHolderName}");
        }

    }
}
