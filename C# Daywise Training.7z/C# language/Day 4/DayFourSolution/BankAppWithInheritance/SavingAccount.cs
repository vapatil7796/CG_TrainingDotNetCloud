﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAppWithInheritance
{
    class SavingAccount:Account
    {
        //Base Class Constructor
        public SavingAccount(int acno,string name,double bal,string branchName) : base(acno, name, bal, branchName)
        {

        }

        //Method only Available for Saving Account Class Object
        public override void Withdraw(double amount)     //Overriding using override keyword
        {
            Console.WriteLine("Saving account wuthdraw is Called");
            if (balance - amount < 1000)
            {
                Console.WriteLine("Insuffiecient Balance");
            }
            else
            {
                balance = balance - amount;
                Console.WriteLine($"Account Balance After Withdraw: {balance} of {accountHolderName});
            }
        }

        public void FreeCC()
        {
            Console.WriteLine("You are eligible for Free Credit Card");
        }
    }
}
