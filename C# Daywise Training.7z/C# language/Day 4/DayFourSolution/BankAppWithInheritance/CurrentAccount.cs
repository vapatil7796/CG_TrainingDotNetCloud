﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAppWithInheritance
{
    class CurrentAccount:Account
    {
        public CurrentAccount(int acno,string name, double bal,string branchName) : base(acno, name, bal, branchName)
        {

        }

        //Method Available Only for Current Account Class Object
        public override void Withdraw(double amount)     //Overriding using override keyword
        {
            Console.WriteLine("Current account wuthdraw is Called");
            if (balance - amount < 5000)
            {
                Console.WriteLine("Insuffiecient Balance");
            }
            else
            {
                balance = balance - amount;
                Console.WriteLine($"Account Balance After Withdraw: {balance} of {accountHolderName}");
            }
        }

        public void FreeInsurance()
        {
            Console.WriteLine("You are eligible for Free Insurance from our side.");
        }
    }
}
