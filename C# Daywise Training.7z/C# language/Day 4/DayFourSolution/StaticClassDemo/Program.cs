﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticClassDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample.IncrementCount();
            Sample.IncrementCount();
            Sample.IncrementCount();

            Console.ReadLine();
        }
    }
}
