﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticClassDemo
{

    static class Sample
    {
        //Static Data members
        static int count;
        //Static Constructor
        static Sample()
        {
            count = 1;
        }

        //Static method
        public static void IncrementCount()
        {
            count = count + 1;
            Console.WriteLine("Current Count value is: " + count);
        }
    }
}
