﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesDemo
{
    class Employee
    {
        //Private Data Members
        int empId;
        string empName;
        double salary;
        string password;
        int age;

        //Properties
        public int Age
        {
            get { return age; }
            set
            {
                if (value < 18)
                {
                    Console.WriteLine("Minor, Age cant be set");
                }
                else
                {
                    age = value;
                }
            }
        }

        public string Password         //Write Only
        {
            //get { return password; }       
            set { password = value; }
        }

        public int EmpId
        {
            get { return empId; }
            set { empId = value; }
        }

        public string EmpName              //Read - Write
        {
            get { return empName; }
            set { empName = value; }
        }

        public double Salary                 //Read Only
        {
            get { return salary; }
            //set { salary = value; }
        }
       
    }
}
