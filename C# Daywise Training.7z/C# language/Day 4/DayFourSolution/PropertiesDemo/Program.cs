﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Access and store the values from Class Employee in Class Program
            Employee employee = new Employee();

            //Store the values
            employee.EmpId = 100;
            employee.EmpName = "Vishal";

            //employee.Salary = 10000;     //We cant set as its Read Only Property

            employee.Age = 18;   //Validate the Age

            //Access
            Console.WriteLine(employee.EmpId);
            Console.WriteLine(employee.EmpName);
            Console.WriteLine(employee.Salary);
            //Console.WriteLine(employee.Password);     //We cant read as its Write Only Property
            Console.WriteLine(employee.Age);

            Console.ReadLine();
        }
    }
}
