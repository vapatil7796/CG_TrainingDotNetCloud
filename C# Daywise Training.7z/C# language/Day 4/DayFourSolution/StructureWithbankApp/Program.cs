﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructureWithbankApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter yor Account Number:");  //Input account no. from user
            int accNum = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter your Name:");  //Input account holder name from user
            string accName = Console.ReadLine();

            Console.WriteLine("Enter your Balance:");  //Input balance from user
            double bal = Convert.ToDouble(Console.ReadLine());

            Account account = new Account(accNum, accName, bal);  //Calling constructor for Input

            Console.WriteLine("Enter Amount to Deposit:");  //Input deposit amount from user
            double amount = Convert.ToDouble(Console.ReadLine());  
            account.Deposit(bal, amount);

            Console.WriteLine("Enter amount to be Withdrawn:");  //Input withdraw amount from user
            amount = Convert.ToDouble(Console.ReadLine());
            account.Withdraw(bal, amount);
            

            Console.ReadLine();
        }
    }
}
