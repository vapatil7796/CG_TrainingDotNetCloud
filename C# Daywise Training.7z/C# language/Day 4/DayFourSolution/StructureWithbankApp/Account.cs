﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructureWithbankApp
{
    public struct Account
    {
        public int accountNumber;
        public string accountHolderName;
        public double balance;

        //Constructor to Initialize variables present in Structure
        public Account(int acNo,string name,double bal)
        {
            accountNumber = acNo;
            accountHolderName = name;
            balance = bal;
        }

        //Function for depositing amount
        public void Deposit(double bal,double amt)
        {
            balance = balance + amt;
            Console.WriteLine($"Your Current Balance after Deposit is {balance}");
        }

        //Function for Withdrawing amount
        public void Withdraw(double bal, double amt)
        {
            balance = balance - amt;
            Console.WriteLine($"Your Current Balance after withdraw is {balance}");
        }
    }
}
