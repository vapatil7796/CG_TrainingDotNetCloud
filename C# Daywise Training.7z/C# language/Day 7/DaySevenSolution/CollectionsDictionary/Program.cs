﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsDictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            //Dictionary Declaration
            Dictionary<string, long> contacts = new Dictionary<string, long>();

            //Adding 'Key --> Value' Pairs in Dictionary
            contacts.Add("Vishal", 51544554441);
            contacts.Add("Aditya", 9655475843);
            contacts.Add("Devendra", 84469572564);
            contacts.Add("Prayag", 65547812549);

            //Printing Dictionary
            PrintContacts(contacts);

            Console.WriteLine($"Number of items in Dictionary: {contacts.Count()}");

            var keysList = contacts.Keys;
            foreach(var k in keysList)
            {
                Console.WriteLine(k);
            }

            var valuesList = contacts.Values;
            foreach (var v in valuesList)
            {
                Console.WriteLine(v);
            }

            contacts.Remove("Aditya");  //Specify the key to remove the item
            PrintContacts(contacts);

            Console.WriteLine($"Mahesh Exits or not: {contacts.ContainsKey("Mahesh")}");
            Console.WriteLine($"Number 84469572564 Exits or not: {contacts.ContainsValue(84469572564)}");

            Console.ReadLine();
        }

        static void PrintContacts(Dictionary<string,long> contact)
        {
            foreach(var item in contact)
            {
                Console.WriteLine($"{item.Key} ==> {item.Value}");
            }
            Console.WriteLine("-----------------------------------------------");
        }
    }
}
