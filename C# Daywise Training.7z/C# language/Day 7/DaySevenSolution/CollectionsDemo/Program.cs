﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declaring List
            List<int> list = new List<int>();

            //Adding Values in the List
            list.Add(25);
            list.Add(45);
            list.Add(21);
            list.Add(55);

            //Printing Values
            Console.WriteLine($"Items in the List: {list.Count}");  //Count Property
            PrintList(list);

            //Other Methods in the List class
            list.Insert(2, 100);    //list.Index(index_pos_where we_want_to_insert_value , value_to_be_inserted);
            PrintList(list);

            list.RemoveAt(1);
            PrintList(list);

            list.Reverse();
            PrintList(list);

            list.Sort();
            PrintList(list);

            Console.WriteLine($"Is 30 Present in List: {list.Contains(30)}");
            Console.WriteLine($"Is 25 Present in List: {list.Contains(25)}");

            list.Add(25);
            Console.WriteLine($"Position of 25 in the List: {list.IndexOf(25)}");
            Console.WriteLine($"Position of 60 in the List: {list.IndexOf(60)}");
            Console.WriteLine($"Last Position of 25 in List: {list.LastIndexOf(25)}");

            //List to Array conversion
            int[] array = list.ToArray();    //List is not destroyed, it only creates array copy of that list

            list.AddRange(new int[] { 2, 44, 76, 87 });  //Add groupof items in list at a time
            PrintList(list);

            /* list.Clear();  //remove all items            */
            /* list.RemoveAll(p => p > 50);  //remove items who are greater than 50                */ 

            int sum1 = list.Sum();
            Console.WriteLine($"Total of all Numbers: {sum1}");

            int sum2= list.Sum(p => p > 50 ? p : 0); //if no. is >50, then add that value otherwise add 0 to sum2
            Console.WriteLine($"Total of all Numbers greater than 50: {sum2}");

            int count = list.Count(p => p > 50);
            Console.WriteLine($"Count of numbers greater than 50: {count}");

            Console.ReadLine();
        }

        static void PrintList(List<int> list)
        {
            foreach (var item in list)
            {
                Console.WriteLine(item + "\t");
            }
            Console.WriteLine("-----------------------------------------------------");
        }
    }
}
