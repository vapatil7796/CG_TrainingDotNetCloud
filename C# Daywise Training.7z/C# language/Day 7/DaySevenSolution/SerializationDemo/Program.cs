﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
using System.Runtime.Serialization.Formatters.Binary;   //Defined by self
using System.Runtime.Serialization.Formatters.Soap;    //Defined by self

using System.Xml.Serialization;   //Defined for XML serialization manually

namespace SerializationDemo
{
    class Program
    {
        static void Main(string[] args)    //We need to Add the Dll in the References : "System.Runtime.Serialization"
        {
            List<Product> products = new List<Product>()     //List of Objects
            {
                new Product{Id=101,Name="Apple",Price=500,Quantity=20},
                new Product{Id=102,Name="Orange",Price=160,Quantity=10},
                new Product{Id=103,Name="Mango",Price=1500,Quantity=30},
            };

            /*   Binary Serialization  */
            //SerializeProducts(products);
            //DeserializeProducts();

            /*   Soap Serialization  */
            //SoapSerialization(products.ToArray());
            //SoapDeserialization();

            /*  XML Serialization  */
            XmlSerialization(products.ToArray());
            XmlDeserialization();

            Console.ReadLine();
        }

        //Methods for Binary Serialization
        static void SerializeProducts(List<Product> products)
        {
            FileStream fs = new FileStream("products.dat", FileMode.Create, FileAccess.Write);
            BinaryFormatter formater = new BinaryFormatter();
            formater.Serialize(fs, products);
            fs.Close();
            Console.WriteLine("Products data written to file Successfully");
        }

        static void DeserializeProducts()
        {
            FileStream fs = new FileStream("products.dat", FileMode.Open, FileAccess.Read);
            BinaryFormatter formater = new BinaryFormatter();
            List<Product> products = formater.Deserialize(fs) as List<Product>;
            fs.Close();
            foreach (var p in products)
            {
                Console.WriteLine($"{0,-4} | {1,-20} | {2,-5} | {3,-5}", p.Id, p.Name, p.Price, p.Quantity);
            }
            Console.WriteLine("Products data written to file Successfully");
        }

        //Methods for SOAP serialization
        static void SoapSerialization(Product[] products)
        {
            FileStream fs = new FileStream("soapdata.xml", FileMode.Create, FileAccess.Write);
            SoapFormatter formatter = new SoapFormatter(); ;
            formatter.Serialize(fs, products);
            fs.Close();
            Console.WriteLine("Serialize the data to soap format");
        }

        static void SoapDeserialization()
        {
            FileStream fs = new FileStream("soapdata.xml", FileMode.Open, FileAccess.Read);
            SoapFormatter formatter = new SoapFormatter();
            Product[] products = formatter.Deserialize(fs) as Product[];
            fs.Close();
            foreach (var p in products)
            {
                Console.WriteLine("{0,-4} | {1,-20} | {2,-5} | {3,-5} ", p.Id, p.Name, p.Price, p.Quantity);
            }
            Console.WriteLine("Products data written to file Successfully");
        }

        //Methods for XML Serialization
        static void XmlSerialization(Product[] products)
        {
            FileStream fs = new FileStream("xmldata.xml", FileMode.Create, FileAccess.Write);
            XmlSerializer ser = new XmlSerializer(typeof(Product[]));   //class of Product must be public
            ser.Serialize(fs, products);
            fs.Close();
            Console.WriteLine("Serialized to XML format");
        }

        static void XmlDeserialization()
        {
            FileStream fs = new FileStream("xmldata.xml", FileMode.Open, FileAccess.Read);
            XmlSerializer ser = new XmlSerializer(typeof(Product[]));
            Product[] products = ser.Deserialize(fs) as Product[];
            fs.Close();
            foreach (var p in products)
            {
                Console.WriteLine("{0,-4} | {1,-20} | {2,-5} | {3,-5} ", p.Id, p.Name, p.Price, p.Quantity);
            }
            Console.WriteLine("Products data written to file Successfully");
        }

    }
}
