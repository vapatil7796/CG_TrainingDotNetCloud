﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomGenericCollection
{
    class Program
    {
        static void Main(string[] args)
        {
            Print<int>(100);
            //Print<string>("Hello ");
            Print<bool>(true);

            Print("Good Morning");   //Second Method
            Print(45);

            Show<string, long>("Vishal", 84456795485);

            Show("Hari", 8965412308);   //Second Method

            Console.ReadLine();
        }

        static void Print<T>(T data)    //Generic Function by adding 'T' datatype :struct for Value type and class for Reference type
        {
            Console.WriteLine(data); 
        }

        static void Show<T,U>(T data, U value)    //Generic Function by adding 'T' datatype
        {
            Console.WriteLine(data);
            Console.WriteLine(value);
        }
    }

    interface MyInterface<T>     //Generic Interface
    {
        void DoSomething(T arg);
    }

    class Cube : MyInterface<int>
    {
        public int Side { get; set; }

        public void DoSomething(int arg)
        {
            Console.WriteLine(Side*Side*Side); 
        }
    }

    class Contact : MyInterface<string>
    {
        public void DoSomething(string arg)
        {
            Console.WriteLine("We are in Contact class using generic interface."+ arg); ;
        }
    }
}
