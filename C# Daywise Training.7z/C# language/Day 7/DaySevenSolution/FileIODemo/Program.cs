﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileIODemo
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream fs = File.Create("sample.txt");  //using fs we're going to perform operations
            fs.Close();
            Console.WriteLine("Press Any Key to Delete the Created File.");
            Console.ReadLine();

            File.Delete("sample.txt");
            var exists = File.Exists("Demo.txt");
            if (exists)
            {
                Console.WriteLine("File Exists");
            }
            else
            {
                Console.WriteLine("File Not Found!");
            }

            //Directory
            Directory.CreateDirectory("MyData");
            Console.WriteLine("Press Enter to Delete Directory.");
            Console.ReadLine();
            Directory.Delete("MyData");

            //FileInfo 
            FileInfo fInfo = new FileInfo(@"C:\Users\vishalap\Desktop\DayToDayTopics.txt");
            Console.WriteLine("Name: "+fInfo.Name);
            Console.WriteLine("Full Name: " + fInfo.FullName);
            Console.WriteLine("File Size: " + fInfo.Length+" Bytes");
            Console.WriteLine("Last Access Time: " + fInfo.LastAccessTime);
            Console.WriteLine("Is Read Only: " + fInfo.IsReadOnly);
            Console.WriteLine("Creation Time: " + fInfo.CreationTime);

            //Directory Info
            DirectoryInfo dInfo = new DirectoryInfo(@"C:\.NET training\Assignments\Module 1\C sharp LabBook\LabTwoSolution");
            Console.WriteLine("Name: "+dInfo.Name);
            Console.WriteLine("Full Name: " + dInfo.FullName);
            Console.WriteLine("Creation Time: " + dInfo.CreationTime);
            Console.WriteLine("Last Access Time: " + dInfo.LastAccessTime);

            foreach(DirectoryInfo dir in dInfo.GetDirectories())    //List of sub Directories
            {
                Console.WriteLine(dir.Name);
            }

            foreach (FileInfo file in dInfo.GetFiles())    //List of files inside Directory
            {
                Console.WriteLine(file.Name);
            }

            Console.ReadLine();
        }
    }
}
