﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            foreach(var item in GetItems())
            {
                Console.WriteLine(item);
            }

            DaysOfWeek daysOfWeek = new DaysOfWeek();
            foreach (var day in daysOfWeek)
            {
                Console.WriteLine(day);
            }

            Console.ReadLine();
        }

        static IEnumerable<int> GetItems()
        {
            yield return 1;
            yield return 2;
            yield return 3;
            yield return 4;

        }
        
        class DaysOfWeek: IEnumerable
        {
            private string[] days = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };

            public IEnumerator GetEnumerator()
            {
                for(var i = 0; i < days.Length; i++)
                {
                    yield return days[i];
                }
            }
        }
    }
}
