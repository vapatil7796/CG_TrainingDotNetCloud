﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileInsertDeleteIO
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream fs = new FileStream("sample.txt", FileMode.CreateNew, FileAccess.Write);
            //FileStream fs = File.Create("sample.txt");    //Second Method to Create file

            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine("This is sample file Demo");    //We're writing in memory
            sw.WriteLine("This is another line in the file.");
            sw.WriteLine("You can write any number of Lines");
            sw.Flush();    //Flush is used to transfer the data from memory to the file
            sw.Close();
            fs.Close();

            fs = new FileStream("sample.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            string content = sr.ReadToEnd();
            Console.WriteLine(content);
            sr.Close();
            fs.Close();

            Console.ReadLine();
        }
    }
}
