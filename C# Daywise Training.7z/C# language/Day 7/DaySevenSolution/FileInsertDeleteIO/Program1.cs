﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileInsertDeleteIO
{
    class Program1
    {
        static void Main()
        {
            //Writing in Binary File
            FileStream fs = new FileStream("BinData.dat", FileMode.Create, FileAccess.Write);
            BinaryWriter bw = new BinaryWriter(fs);
            bw.Write("Some Binary Text");
            bw.Close();
            fs.Close();

            //Reading from Binary File
            fs = new FileStream("BinData.dat", FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            var content = br.ReadString();
            Console.WriteLine(content);
            br.Close();
            fs.Close();

            Console.ReadLine();
        }
    }
}
