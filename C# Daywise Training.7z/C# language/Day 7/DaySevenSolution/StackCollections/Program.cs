﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StackCollections
{
    class Program
    {
        static void Main(string[] args)
        {
            //STACK
            Stack<int> st = new Stack<int>();
            st.Push(10);
            st.Push(20);
            st.Push(30);
            st.Push(40);

            Console.WriteLine($"Top of the Stack/ Peek Element: {st.Peek()}");   //shows top of the stack element

            Console.WriteLine($"Poped Item: {st.Pop()}");    //shows top of the stack element after poping
            Console.WriteLine($"Poped Item: {st.Pop()}");
            Console.WriteLine($"Poped Item: {st.Pop()}");

            //QUEUE
            Queue<int> q = new Queue<int>();
            q.Enqueue(10);
            q.Enqueue(20);
            q.Enqueue(30);
            q.Enqueue(40);

            Console.WriteLine($"First Element of Queue/ Peek Element: {q.Peek()}");   //shows first element of Queue

            Console.WriteLine($"Poped Item: {q.Dequeue()}");    //shows first element of Queue after Dequeuing
            Console.WriteLine($"Poped Item: {q.Dequeue()}");
            Console.WriteLine($"Poped Item: {q.Dequeue()}");

            Console.ReadLine();
        }
    }
}
