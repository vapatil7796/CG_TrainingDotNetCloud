﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApp
{
    class Account
    {
        //Data Members
        int accountNumber = 10;
        double balance = 20000.323232;
        string accountHolderName = "Vishal";

        //Member Functions
        public double Deposit(double amount)
        {
            balance = balance + amount;
            return balance;
        }
        public double Withdraw(double amount)
        {
            balance = balance - amount;
            return balance;
        }
    }
}
