﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //create object
            Account account = new Account();

            double newBalance = account.Deposit(200.4242);
            Console.WriteLine("New Balance after Deposite is:" + newBalance);

            newBalance = account.Withdraw(100);
            Console.WriteLine("New Balance ahter Withdraw is:" + newBalance);

            Console.ReadLine();
        }
    }
}
