﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //object creation
            Calculator calculator = new Calculator();
            int result = calculator.Addition(10, 20);
            Console.WriteLine("Addition is:" + result);

            Console.ReadLine(); //To keep console screen steady
        }
    }
}
