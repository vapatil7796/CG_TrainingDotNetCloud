﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathSolution
{
    class Program
    {
        static void Main(string[] args)
        {
            Math math = new Math();

            int result = math.Add(20, 10);
            Console.WriteLine("Addition is:" + result);

            result = math.Sub(20, 10);
            Console.WriteLine("Subtraction is:" + result);

            result = math.Mul(20, 10);
            Console.WriteLine("Multiplication is:" + result);

            result = math.Div(20, 10);
            Console.WriteLine("Division is:" + result);

            Console.ReadLine();
        }
    }
}
