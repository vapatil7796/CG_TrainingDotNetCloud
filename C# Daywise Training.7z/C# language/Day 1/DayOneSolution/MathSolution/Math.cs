﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathSolution
{
    class Math
    {
        public int Add(int num1, int num2)  //Addition
        {
            int a = num1 + num2;
            return a;
        }
        public int Sub(int num1, int num2)  //Subtraction
        {
            int a = num1 - num2;
            return a;
        }
        public int Mul(int num1, int num2)  //Multiplication
        {
            int a = num1 * num2;
            return a;
        }
        public int Div(int num1, int num2)  //Division
        {
            int a = num1 / num2;
            return a;
        }
    }
}
