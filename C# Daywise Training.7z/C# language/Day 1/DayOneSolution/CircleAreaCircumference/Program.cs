﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircleAreaCircumference
{
    class Program
    {
        static void Main(string[] args)
        {
            Circle circle = new Circle();

            double area = circle.Area(8.25);
            Console.WriteLine("Area is:" + area);
            double circumference = circle.Circumference(8.25);
            Console.WriteLine("Circumference is:" + circumference);
            Console.ReadLine();

        }
    }
}
