﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircleAreaCircumference
{
    class Circle
    {
        //Data Member
        double pi = 3.142;

        //Member Function
        public double Area(double a)
        {
            double area = pi * a * a;
            return area;
        }

        public double Circumference(double a)
        {
            double circumference = 2 * pi * a;
            return circumference;
        }
    }
}
