﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmsEntities
{
    public class Student
    {
        //Public Properties
        public int RollNo { get; set; }
        public string Name { get; set; }
        public int Marks { get; set; }
    }
}
