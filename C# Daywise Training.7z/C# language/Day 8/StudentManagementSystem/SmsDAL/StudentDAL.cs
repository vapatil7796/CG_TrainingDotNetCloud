﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SmsEntities;
using SmsExceptions;

namespace SmsDAL
{
    public class StudentDAL
    {
        private static List<Student> students = new List<Student>();

        /// <summary>
        /// Adding a new Student to the Data Storage
        /// </summary>
        /// <param name="s"></param>

        public void Add(Student s)
        {
            students.Add(s);
        }

        /// <summary>
        /// Returns the list of all students
        /// </summary>
        /// <returns>IEnumerable<Student></returns>

        public IEnumerable<Student> GetAll()
        {
            return students;
        }

        /// <summary>
        /// Search for the Student and remove it from storage
        /// </summary>
        /// <param name="rno"></param>

        public void Remove(int rno)
        {
            var stud = students.Find(s => s.RollNo == rno);
            if (stud == null)
            {
                throw new StudentNotFoundException();
            }
            students.Remove(stud);
        }

        /// <summary>
        /// Search for the Student with roll number and Returns
        /// </summary>
        /// <param name="rollNo"></param>
        /// <returns>Student</returns>

        public Student GetByRollNo(int rollNo)
        {
            var stud = students.Find(s => s.RollNo == rollNo);
            if (stud == null)
            {
                throw new StudentNotFoundException();
            }
            return stud;
        }
    }
}
