﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SmsEntities;
using SmsExceptions;
using SmsDAL;

namespace SmsBLL
{
    public class StudentBLL
    {
        public void AddStudent(Student s)
        {
            if (s.RollNo <= 0)
            {
                throw new InvalidRollNumberException();
            }
            if (s.Name.Length<=2)  
            {
                throw new InvalidNameException();
            }
            //Later

            StudentDAL dal = new StudentDAL();
            dal.Add(s);
        }

        public void RemoveStudent(int rollNo)
        {
            if (rollNo <= 0)
            {
                throw new InvalidRollNumberException();
            }
            StudentDAL dal = new StudentDAL();
            dal.Remove(rollNo);
        }

        public IEnumerable<Student> GetStudents()
        {
            StudentDAL dal = new StudentDAL();
            return dal.GetAll();
        }

        public Student GetStudent(int rollNo)
        {
            if (rollNo <= 0)
                throw new InvalidRollNumberException();
            StudentDAL dal = new StudentDAL();
            return dal.GetByRollNo(rollNo);
        }
    }
}
