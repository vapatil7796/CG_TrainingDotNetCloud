﻿using System;

using SmsBLL;
using SmsEntities;

namespace StudentManagementSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            StudentBLL bll = new StudentBLL();
            while (true)
            {
                Console.Clear();   //clears the screen

                Console.WriteLine("Enter Choice: ");
                Console.WriteLine("1. Add Student\n2. List Student\n3. Search\n4. Remove\n5. Exit");
                int choice = Convert.ToInt32(Console.ReadLine());
                if (choice == 1)
                {
                    Student s = new Student();
                    Console.WriteLine("Enter roll No: ");
                    s.RollNo = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Name: ");
                    s.Name = Console.ReadLine();
                    Console.WriteLine("Enter Marks: ");
                    s.Marks = Convert.ToInt32(Console.ReadLine());
                    bll.AddStudent(s);
                    Console.WriteLine("Student Added Successfully");
                }
                else if (choice == 2)
                {
                    var students = bll.GetStudents();
                    foreach (var s in students)
                    {
                        Console.WriteLine("{0,-3}|{1,-3}|{2,-3}", s.RollNo, s.Name, s.Marks);
                    }
                }
                else if (choice == 5)
                {
                    break;
                }

                Console.WriteLine("Please ENTER to Continue.....");
                Console.ReadLine();
            }
        }
    }
}
