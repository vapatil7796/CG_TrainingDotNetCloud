﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmsExceptions
{
    public class StudentNotFoundException:Exception
    {
        string message = "Student you are searching is not found";

        public override string Message
        {
            get { return message; }
        }

    }
}
