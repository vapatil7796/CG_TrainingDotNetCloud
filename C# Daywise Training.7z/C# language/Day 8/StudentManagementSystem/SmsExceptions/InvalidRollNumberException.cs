﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmsExceptions
{
    public class InvalidRollNumberException:Exception
    {

        public override string Message
        {
            get { return "Invalid roll number Provided"; }
        }
    }
}
