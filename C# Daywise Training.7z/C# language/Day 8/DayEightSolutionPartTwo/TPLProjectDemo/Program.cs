﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;   //for Parallelism of Tasks

using System.Threading;

namespace TPLProjectDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            PrintWithoutParallelism();

            Console.WriteLine("------------------------------------------------------");

            PrintWithParallelism();
            Parallel.Invoke(Print, Print1, Print2);           //Any number of Functions can be executed parallely

            Parallel.Invoke
            (
                () => SayGreeting("Hello", 2),
                () => Table(9)
            );

            Console.ReadLine();
        }

        static void PrintWithoutParallelism()
        {
            for (int i = 1; i <= 100; i++)
            {
                Console.Write(i + " ");
                Task.Delay(100);
            }
        }

        static void PrintWithParallelism()
        {
            Parallel.For(1, 101, (i) =>
             {
                 Console.Write(i + " ");
                 Task.Delay(100);
             });
        }

        //Just made to check parallelism using Parallel.Invoke(.....); method
        static void Print()
        {
            for (int i = 1; i <= 100; i++)
            {
                Console.WriteLine(i);
                Thread.Sleep(100);
            }
        }

        static void Print1()
        {
            for (int i = 101; i <= 110; i++)
            {
                Console.WriteLine(i);
                Thread.Sleep(100);
            }
        }

        static void Print2()
        {
            for (int i = 201; i <= 210; i++)
            {
                Console.WriteLine(i);
                Thread.Sleep(100);
            }
        }

        static void SayGreeting(string msg, int count)
        {
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine(msg);
            }
        }

        static void Table(int num)
        {
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine($"{num} * {i} = {num * i}");
            }
        }
    }
}
