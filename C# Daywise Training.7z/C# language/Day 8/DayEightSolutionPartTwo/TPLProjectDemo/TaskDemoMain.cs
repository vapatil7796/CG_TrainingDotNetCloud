﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Threading;

namespace TPLProjectDemo
{
    class TaskDemoMain
    {
        static void Main()
        {
            Task t = new Task(()=> 
            {
                int sum = GetTotal(200, 520);
                Console.WriteLine("Sum is: "+sum);
            });
            t.Start();     //to start execution

            //Method Two
            Task.Factory.StartNew(() =>
            {
                int sum = GetTotal(200, 520);        //No need to start explicitly
                Console.WriteLine("Sum is: " + sum);            
            }).ContinueWith((prevTask)=>
            {
                Console.WriteLine("Task is Completed");
            });

            Console.WriteLine("Main method is Completed");

            Console.ReadLine();
        }

        static int GetTotal(int start, int end)
        {
            int sum = 0;
            for(int i = start; i <= end; i++)
            {
                sum += i;
                Thread.Sleep(10);
            }
            return sum;
        }
    }
}
