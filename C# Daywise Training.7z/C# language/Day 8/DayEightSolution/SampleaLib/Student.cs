﻿using System;

namespace SampleaLib
{
    [Author("Vishal")]
    [Author("Rahul", Description = "Bug is Fixed")]
    [Author("Jay", ModifiedDate = "08/05/2019", Description = "Class Modified")]

    public class Student    //To create DLL, if not public then we cannot access in Reflection Demo class
    {
        //Properties
        public int Id { get; set; }

        public string Name { get; set; }

        public int Mark { get; set; }

        //Applying attribute to constructor
        [Author("Vishal", Description = "Added for Simplicity")]
        [Author("Shekhar", ModifiedDate = "04/05/2019", Description = "Added for Simplicity by Another Author")]   //Second Author 

        //Default Constructor
        public Student()
        {

        }
        //Applying attribute to parametrized Constructor
        [Author("Vishal", Description = "Initializing with Values", ModifiedDate = "12/04/2019")]

        //Parametrized Constructor
        public Student(int id, string name, int mark)
        {
            this.Id = id;
            this.Name = name;
            this.Mark = mark;
        }

        //Applying attribute to Method
        [Author("Vishal", ModifiedDate = "10/03/2019")]
        [Author("Ashwin")]

        //Method
        public void Show()
        {
            Console.WriteLine("Name: " + Name);
            Console.WriteLine("ID: " + Id);
            Console.WriteLine("Marks: " + Mark);
        }

    }
}
