﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleaLib
{
    //Custom Attribute Class creation
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Constructor | AttributeTargets.Class, AllowMultiple = true)]

    public class AuthorAttribute : Attribute  //For Attributes.... Attribute is Parent class
    {
        private string name;
        private string description;
        private string modifiedDate;

        //Constructor for Initialize
        public AuthorAttribute(string name)
        {
            this.name = name;
        }

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public string Name 
        {
            get { return name; }
        }

        public string ModifiedDate
        {
            get { return modifiedDate; }
            set { modifiedDate = value; }
        }

    }
}
