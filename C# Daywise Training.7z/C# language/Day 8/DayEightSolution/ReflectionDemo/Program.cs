﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SampleaLib;   //self imported library

using System.Reflection;//

namespace ReflectionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly assembly = Assembly.LoadFile(@"C:\.NET training\Day 8\DayEightSolution\SampleaLib\bin\Debug\netstandard2.0\SampleaLib.dll");

            Type[] types = assembly.GetTypes();  //All The Types
            foreach (Type t in types)
            {
                Console.WriteLine(t.Name);
            }
            Console.WriteLine("------------------------------------------");

            //for showing Property name and property type of the Student class
            Type studentType = assembly.GetType("SampleaLib.Student");    //Get only one Type
            PropertyInfo[] properties = studentType.GetProperties();
            foreach (var p in properties)
            {
                Console.WriteLine(p.PropertyType.Name + " " + p.Name);
            }
            Console.WriteLine("------------------------------------------");

            //For showing All the Methods
            MethodInfo[] methods = studentType.GetMethods();
            foreach (var m in methods)
            {
                Console.WriteLine(m.ReturnType.Name + " " + m.Name);
            }
            Console.WriteLine("------------------------------------------");

            //For Showing Attribute types
            Student student = new Student();
            studentType = student.GetType();
            var attributes = studentType.GetCustomAttributes();
            foreach (var a in attributes)
            {
                if(a is AuthorAttribute)
                {
                    var autherAttrib = (AuthorAttribute)a;
                    Console.WriteLine(autherAttrib.Name);
                    Console.WriteLine(autherAttrib.ModifiedDate);
                    Console.WriteLine(autherAttrib.Description);
                }
            }
            Console.WriteLine("------------------------------------------");

            Console.ReadLine();
        }
    }
}
