﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPLDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //using optional Parameters
            Show(22, "Ajay", "M", "FC");
            Show(25, "Parvati", "F");
            Show(26, "Sekhar");
            //using named Parameters
            Show(30, "Dinesh", category: "AC");
            Show(name: "Mike", category: "GD", age: 61);  //we can write in any sequence

            Console.ReadLine();
        }

        static void Show(int age, string name, string gender="M", string category = "General")
        {
            //print values here
            Console.WriteLine($"Name:    {name}");
            Console.WriteLine($"Age:     {age}");
            Console.WriteLine($"Gender:  {gender}");
            Console.WriteLine($"Category:{category}");
        }
    }
}
