﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPLDemo
{
    class Program1
    {
        static void Main()
        {
            var d = "Hello";
            dynamic data;
            data = "Hello";
            Console.WriteLine(d.ToUpper());
            Console.WriteLine(data.ToUpper());

            Show(10);
            Show("Hello Friends");
            Show(true);

            Student s = new Student();
            s.id = 33;
            s.name = "Vishal";

            Student s2 = new Student();
            s2.id = "A1232";
            s2.name = "Kamal";

            Console.ReadLine();
        }


        static void Show(dynamic args)
        {
            Console.WriteLine(args);
        }
    }

    class Student
    {
        public dynamic id;
        public string name;
    }
    
}
